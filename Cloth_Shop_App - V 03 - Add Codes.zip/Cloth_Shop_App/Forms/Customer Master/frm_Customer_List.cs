﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Customer_Master
{
    public partial class frm_Customer_List : Form
    {
        public frm_Customer_List()
        {
            InitializeComponent();
        }
    }
}
