﻿namespace Cloth_Shop_App.Forms.Expence_Master
{
    partial class frm_Add_Expence_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Expence_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Expence_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_Browse_Bill = new System.Windows.Forms.Button();
            this.cmb_Bill_Paid_By = new System.Windows.Forms.ComboBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.tb_Amount_Paid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pb_Bill_Image = new System.Windows.Forms.PictureBox();
            this.tb_Expence_Details = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tb_Expence_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pnl_Header = new System.Windows.Forms.Panel();
            this.gb_Expence_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Bill_Image)).BeginInit();
            this.pnl_Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(220, 500);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(150, 47);
            this.btn_Refresh.TabIndex = 8;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Save.Location = new System.Drawing.Point(570, 500);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(137, 47);
            this.btn_Save.TabIndex = 7;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // gb_Expence_Details
            // 
            this.gb_Expence_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Expence_Details.Controls.Add(this.dtp_Expence_Date);
            this.gb_Expence_Details.Controls.Add(this.btn_Browse_Bill);
            this.gb_Expence_Details.Controls.Add(this.cmb_Bill_Paid_By);
            this.gb_Expence_Details.Controls.Add(this.Label6);
            this.gb_Expence_Details.Controls.Add(this.tb_Amount_Paid);
            this.gb_Expence_Details.Controls.Add(this.label2);
            this.gb_Expence_Details.Controls.Add(this.pb_Bill_Image);
            this.gb_Expence_Details.Controls.Add(this.tb_Expence_Details);
            this.gb_Expence_Details.Controls.Add(this.label13);
            this.gb_Expence_Details.Controls.Add(this.Label7);
            this.gb_Expence_Details.Controls.Add(this.label12);
            this.gb_Expence_Details.Controls.Add(this.tb_Expence_ID);
            this.gb_Expence_Details.Controls.Add(this.label1);
            this.gb_Expence_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Expence_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Expence_Details.Location = new System.Drawing.Point(13, 101);
            this.gb_Expence_Details.Name = "gb_Expence_Details";
            this.gb_Expence_Details.Size = new System.Drawing.Size(859, 385);
            this.gb_Expence_Details.TabIndex = 19;
            this.gb_Expence_Details.TabStop = false;
            this.gb_Expence_Details.Text = "Expence Details";
            // 
            // dtp_Expence_Date
            // 
            this.dtp_Expence_Date.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.dtp_Expence_Date.Location = new System.Drawing.Point(614, 36);
            this.dtp_Expence_Date.Name = "dtp_Expence_Date";
            this.dtp_Expence_Date.Size = new System.Drawing.Size(212, 29);
            this.dtp_Expence_Date.TabIndex = 4;
            // 
            // btn_Browse_Bill
            // 
            this.btn_Browse_Bill.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Browse_Bill.Font = new System.Drawing.Font("Bodoni MT Condensed", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse_Bill.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Browse_Bill.Location = new System.Drawing.Point(653, 251);
            this.btn_Browse_Bill.Name = "btn_Browse_Bill";
            this.btn_Browse_Bill.Size = new System.Drawing.Size(138, 35);
            this.btn_Browse_Bill.TabIndex = 5;
            this.btn_Browse_Bill.Text = "Browse Bill Image";
            this.btn_Browse_Bill.UseVisualStyleBackColor = false;
            // 
            // cmb_Bill_Paid_By
            // 
            this.cmb_Bill_Paid_By.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Bill_Paid_By.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Bill_Paid_By.FormattingEnabled = true;
            this.cmb_Bill_Paid_By.Location = new System.Drawing.Point(614, 321);
            this.cmb_Bill_Paid_By.MaxLength = 20;
            this.cmb_Bill_Paid_By.Name = "cmb_Bill_Paid_By";
            this.cmb_Bill_Paid_By.Size = new System.Drawing.Size(212, 31);
            this.cmb_Bill_Paid_By.TabIndex = 6;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.Label6.ForeColor = System.Drawing.Color.DarkRed;
            this.Label6.Location = new System.Drawing.Point(470, 319);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(76, 37);
            this.Label6.TabIndex = 117;
            this.Label6.Text = "Paid By";
            // 
            // tb_Amount_Paid
            // 
            this.tb_Amount_Paid.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Amount_Paid.Location = new System.Drawing.Point(192, 320);
            this.tb_Amount_Paid.MaxLength = 8;
            this.tb_Amount_Paid.Name = "tb_Amount_Paid";
            this.tb_Amount_Paid.Size = new System.Drawing.Size(210, 32);
            this.tb_Amount_Paid.TabIndex = 3;
            this.tb_Amount_Paid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(29, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 37);
            this.label2.TabIndex = 116;
            this.label2.Text = "Amount Paid";
            // 
            // pb_Bill_Image
            // 
            this.pb_Bill_Image.BackColor = System.Drawing.SystemColors.Control;
            this.pb_Bill_Image.Location = new System.Drawing.Point(614, 105);
            this.pb_Bill_Image.Name = "pb_Bill_Image";
            this.pb_Bill_Image.Size = new System.Drawing.Size(212, 140);
            this.pb_Bill_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Bill_Image.TabIndex = 113;
            this.pb_Bill_Image.TabStop = false;
            // 
            // tb_Expence_Details
            // 
            this.tb_Expence_Details.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Expence_Details.Location = new System.Drawing.Point(192, 145);
            this.tb_Expence_Details.MaxLength = 80;
            this.tb_Expence_Details.Multiline = true;
            this.tb_Expence_Details.Name = "tb_Expence_Details";
            this.tb_Expence_Details.Size = new System.Drawing.Size(210, 78);
            this.tb_Expence_Details.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(29, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(140, 37);
            this.label13.TabIndex = 112;
            this.label13.Text = "Expence Details";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.Label7.ForeColor = System.Drawing.Color.DarkRed;
            this.Label7.Location = new System.Drawing.Point(457, 35);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(123, 37);
            this.Label7.TabIndex = 111;
            this.Label7.Text = "Expence Date";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.label12.ForeColor = System.Drawing.Color.DarkRed;
            this.label12.Location = new System.Drawing.Point(470, 158);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 37);
            this.label12.TabIndex = 110;
            this.label12.Text = "Bill Image";
            // 
            // tb_Expence_ID
            // 
            this.tb_Expence_ID.Enabled = false;
            this.tb_Expence_ID.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Expence_ID.Location = new System.Drawing.Point(192, 36);
            this.tb_Expence_ID.MaxLength = 5;
            this.tb_Expence_ID.Name = "tb_Expence_ID";
            this.tb_Expence_ID.Size = new System.Drawing.Size(210, 32);
            this.tb_Expence_ID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Uighur", 21F);
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(29, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 37);
            this.label1.TabIndex = 109;
            this.label1.Text = "Expence Id";
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LawnGreen;
            this.lbl_Header.Location = new System.Drawing.Point(259, 22);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(433, 45);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add Expence Details";
            // 
            // pnl_Header
            // 
            this.pnl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Header.Controls.Add(this.lbl_Header);
            this.pnl_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Header.Location = new System.Drawing.Point(0, 0);
            this.pnl_Header.Name = "pnl_Header";
            this.pnl_Header.Size = new System.Drawing.Size(884, 92);
            this.pnl_Header.TabIndex = 18;
            // 
            // frm_Add_Expence_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Expence_Details);
            this.Controls.Add(this.pnl_Header);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_Expence_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Expence Details";
            this.Load += new System.EventHandler(this.frm_Add_Expence_Details_Load);
            this.gb_Expence_Details.ResumeLayout(false);
            this.gb_Expence_Details.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Bill_Image)).EndInit();
            this.pnl_Header.ResumeLayout(false);
            this.pnl_Header.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox gb_Expence_Details;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel pnl_Header;
        internal System.Windows.Forms.ComboBox cmb_Bill_Paid_By;
        private System.Windows.Forms.Label Label6;
        private System.Windows.Forms.TextBox tb_Amount_Paid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pb_Bill_Image;
        private System.Windows.Forms.TextBox tb_Expence_Details;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tb_Expence_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Browse_Bill;
        private System.Windows.Forms.DateTimePicker dtp_Expence_Date;
    }
}