﻿namespace Cloth_Shop_App.Forms.Dealer_Master
{
    partial class frm_Add_New_Dealer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pnl_Header = new System.Windows.Forms.Panel();
            this.gb_Dealer_Details = new System.Windows.Forms.GroupBox();
            this.btn_Browse_Docs = new System.Windows.Forms.Button();
            this.dtp_Tie_Up_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Office_Address = new System.Windows.Forms.TextBox();
            this.tb_Bank_Details = new System.Windows.Forms.TextBox();
            this.tb_PAN_No = new System.Windows.Forms.TextBox();
            this.tb_Udyam_Adhaar_No = new System.Windows.Forms.TextBox();
            this.tb_Alt_Contact_No = new System.Windows.Forms.TextBox();
            this.tb_Mob_No = new System.Windows.Forms.TextBox();
            this.tb_Dealer_Name = new System.Windows.Forms.TextBox();
            this.tb_Dealer_ID = new System.Windows.Forms.TextBox();
            this.lbl_Dealer_Name = new System.Windows.Forms.Label();
            this.lbl_Bank_Details = new System.Windows.Forms.Label();
            this.lbl_PAN_No = new System.Windows.Forms.Label();
            this.lbl_Udyam_Adhaar_No = new System.Windows.Forms.Label();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.lbl_Office_Address = new System.Windows.Forms.Label();
            this.lbl_Alt_Contact_No = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Dealer_ID = new System.Windows.Forms.Label();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.pnl_Header.SuspendLayout();
            this.gb_Dealer_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(220, 500);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(150, 47);
            this.btn_Refresh.TabIndex = 12;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Save.Location = new System.Drawing.Point(570, 500);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(137, 47);
            this.btn_Save.TabIndex = 11;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LawnGreen;
            this.lbl_Header.Location = new System.Drawing.Point(290, 24);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(347, 45);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Dealer";
            // 
            // pnl_Header
            // 
            this.pnl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Header.Controls.Add(this.lbl_Header);
            this.pnl_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Header.Location = new System.Drawing.Point(0, 0);
            this.pnl_Header.Name = "pnl_Header";
            this.pnl_Header.Size = new System.Drawing.Size(884, 92);
            this.pnl_Header.TabIndex = 18;
            // 
            // gb_Dealer_Details
            // 
            this.gb_Dealer_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Dealer_Details.Controls.Add(this.btn_Browse_Docs);
            this.gb_Dealer_Details.Controls.Add(this.dtp_Tie_Up_Date);
            this.gb_Dealer_Details.Controls.Add(this.tb_Office_Address);
            this.gb_Dealer_Details.Controls.Add(this.tb_Bank_Details);
            this.gb_Dealer_Details.Controls.Add(this.tb_PAN_No);
            this.gb_Dealer_Details.Controls.Add(this.tb_Udyam_Adhaar_No);
            this.gb_Dealer_Details.Controls.Add(this.tb_Alt_Contact_No);
            this.gb_Dealer_Details.Controls.Add(this.tb_Mob_No);
            this.gb_Dealer_Details.Controls.Add(this.tb_Dealer_Name);
            this.gb_Dealer_Details.Controls.Add(this.tb_Dealer_ID);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Dealer_Name);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Bank_Details);
            this.gb_Dealer_Details.Controls.Add(this.lbl_PAN_No);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Udyam_Adhaar_No);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Note);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Office_Address);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Alt_Contact_No);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Dealer_ID);
            this.gb_Dealer_Details.Controls.Add(this.lbl_Tie_Up_Date);
            this.gb_Dealer_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Dealer_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Dealer_Details.Location = new System.Drawing.Point(13, 99);
            this.gb_Dealer_Details.Name = "gb_Dealer_Details";
            this.gb_Dealer_Details.Size = new System.Drawing.Size(859, 385);
            this.gb_Dealer_Details.TabIndex = 20;
            this.gb_Dealer_Details.TabStop = false;
            this.gb_Dealer_Details.Text = "Dealer Details";
            // 
            // btn_Browse_Docs
            // 
            this.btn_Browse_Docs.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Browse_Docs.Font = new System.Drawing.Font("Bodoni MT Condensed", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse_Docs.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Browse_Docs.Location = new System.Drawing.Point(469, 323);
            this.btn_Browse_Docs.Name = "btn_Browse_Docs";
            this.btn_Browse_Docs.Size = new System.Drawing.Size(138, 35);
            this.btn_Browse_Docs.TabIndex = 10;
            this.btn_Browse_Docs.Text = "Browse Documents";
            this.btn_Browse_Docs.UseVisualStyleBackColor = false;
            // 
            // dtp_Tie_Up_Date
            // 
            this.dtp_Tie_Up_Date.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.dtp_Tie_Up_Date.Location = new System.Drawing.Point(637, 26);
            this.dtp_Tie_Up_Date.Name = "dtp_Tie_Up_Date";
            this.dtp_Tie_Up_Date.Size = new System.Drawing.Size(195, 29);
            this.dtp_Tie_Up_Date.TabIndex = 6;
            // 
            // tb_Office_Address
            // 
            this.tb_Office_Address.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Office_Address.Location = new System.Drawing.Point(196, 283);
            this.tb_Office_Address.MaxLength = 120;
            this.tb_Office_Address.Multiline = true;
            this.tb_Office_Address.Name = "tb_Office_Address";
            this.tb_Office_Address.Size = new System.Drawing.Size(212, 75);
            this.tb_Office_Address.TabIndex = 5;
            // 
            // tb_Bank_Details
            // 
            this.tb_Bank_Details.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Bank_Details.Location = new System.Drawing.Point(637, 218);
            this.tb_Bank_Details.MaxLength = 120;
            this.tb_Bank_Details.Multiline = true;
            this.tb_Bank_Details.Name = "tb_Bank_Details";
            this.tb_Bank_Details.Size = new System.Drawing.Size(195, 75);
            this.tb_Bank_Details.TabIndex = 9;
            this.tb_Bank_Details.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_AlphaNumeric);
            // 
            // tb_PAN_No
            // 
            this.tb_PAN_No.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_PAN_No.Location = new System.Drawing.Point(637, 151);
            this.tb_PAN_No.MaxLength = 10;
            this.tb_PAN_No.Name = "tb_PAN_No";
            this.tb_PAN_No.Size = new System.Drawing.Size(195, 32);
            this.tb_PAN_No.TabIndex = 8;
            this.tb_PAN_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_AlphaNumeric);
            // 
            // tb_Udyam_Adhaar_No
            // 
            this.tb_Udyam_Adhaar_No.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Udyam_Adhaar_No.Location = new System.Drawing.Point(637, 83);
            this.tb_Udyam_Adhaar_No.MaxLength = 12;
            this.tb_Udyam_Adhaar_No.Name = "tb_Udyam_Adhaar_No";
            this.tb_Udyam_Adhaar_No.Size = new System.Drawing.Size(195, 32);
            this.tb_Udyam_Adhaar_No.TabIndex = 7;
            this.tb_Udyam_Adhaar_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Alt_Contact_No
            // 
            this.tb_Alt_Contact_No.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Alt_Contact_No.Location = new System.Drawing.Point(196, 219);
            this.tb_Alt_Contact_No.MaxLength = 10;
            this.tb_Alt_Contact_No.Name = "tb_Alt_Contact_No";
            this.tb_Alt_Contact_No.Size = new System.Drawing.Size(212, 32);
            this.tb_Alt_Contact_No.TabIndex = 4;
            this.tb_Alt_Contact_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Mob_No
            // 
            this.tb_Mob_No.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Mob_No.Location = new System.Drawing.Point(196, 151);
            this.tb_Mob_No.MaxLength = 10;
            this.tb_Mob_No.Name = "tb_Mob_No";
            this.tb_Mob_No.Size = new System.Drawing.Size(212, 32);
            this.tb_Mob_No.TabIndex = 3;
            this.tb_Mob_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Dealer_Name
            // 
            this.tb_Dealer_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Dealer_Name.Location = new System.Drawing.Point(196, 83);
            this.tb_Dealer_Name.MaxLength = 120;
            this.tb_Dealer_Name.Name = "tb_Dealer_Name";
            this.tb_Dealer_Name.Size = new System.Drawing.Size(212, 32);
            this.tb_Dealer_Name.TabIndex = 2;
            this.tb_Dealer_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Dealer_ID
            // 
            this.tb_Dealer_ID.Enabled = false;
            this.tb_Dealer_ID.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Dealer_ID.Location = new System.Drawing.Point(196, 27);
            this.tb_Dealer_ID.MaxLength = 5;
            this.tb_Dealer_ID.Name = "tb_Dealer_ID";
            this.tb_Dealer_ID.Size = new System.Drawing.Size(212, 32);
            this.tb_Dealer_ID.TabIndex = 1;
            // 
            // lbl_Dealer_Name
            // 
            this.lbl_Dealer_Name.AutoSize = true;
            this.lbl_Dealer_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Dealer_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dealer_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Dealer_Name.Location = new System.Drawing.Point(26, 82);
            this.lbl_Dealer_Name.Name = "lbl_Dealer_Name";
            this.lbl_Dealer_Name.Size = new System.Drawing.Size(119, 37);
            this.lbl_Dealer_Name.TabIndex = 22;
            this.lbl_Dealer_Name.Text = "Dealer Name";
            // 
            // lbl_Bank_Details
            // 
            this.lbl_Bank_Details.AutoSize = true;
            this.lbl_Bank_Details.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Bank_Details.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bank_Details.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Bank_Details.Location = new System.Drawing.Point(462, 219);
            this.lbl_Bank_Details.Name = "lbl_Bank_Details";
            this.lbl_Bank_Details.Size = new System.Drawing.Size(116, 37);
            this.lbl_Bank_Details.TabIndex = 22;
            this.lbl_Bank_Details.Text = "Bank Details";
            // 
            // lbl_PAN_No
            // 
            this.lbl_PAN_No.AutoSize = true;
            this.lbl_PAN_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PAN_No.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PAN_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_PAN_No.Location = new System.Drawing.Point(462, 151);
            this.lbl_PAN_No.Name = "lbl_PAN_No";
            this.lbl_PAN_No.Size = new System.Drawing.Size(90, 37);
            this.lbl_PAN_No.TabIndex = 22;
            this.lbl_PAN_No.Text = "PAN No.";
            // 
            // lbl_Udyam_Adhaar_No
            // 
            this.lbl_Udyam_Adhaar_No.AutoSize = true;
            this.lbl_Udyam_Adhaar_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Udyam_Adhaar_No.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Udyam_Adhaar_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Udyam_Adhaar_No.Location = new System.Drawing.Point(462, 83);
            this.lbl_Udyam_Adhaar_No.Name = "lbl_Udyam_Adhaar_No";
            this.lbl_Udyam_Adhaar_No.Size = new System.Drawing.Size(169, 37);
            this.lbl_Udyam_Adhaar_No.TabIndex = 22;
            this.lbl_Udyam_Adhaar_No.Text = "Udyam Adhaar No.";
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Note.Font = new System.Drawing.Font("Microsoft Uighur", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.ForeColor = System.Drawing.Color.DarkViolet;
            this.lbl_Note.Location = new System.Drawing.Point(624, 335);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(75, 23);
            this.lbl_Note.TabIndex = 22;
            this.lbl_Note.Text = "*Pdf  File Only";
            // 
            // lbl_Office_Address
            // 
            this.lbl_Office_Address.AutoSize = true;
            this.lbl_Office_Address.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Office_Address.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Office_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Office_Address.Location = new System.Drawing.Point(26, 281);
            this.lbl_Office_Address.Name = "lbl_Office_Address";
            this.lbl_Office_Address.Size = new System.Drawing.Size(131, 37);
            this.lbl_Office_Address.TabIndex = 22;
            this.lbl_Office_Address.Text = "Office Address";
            // 
            // lbl_Alt_Contact_No
            // 
            this.lbl_Alt_Contact_No.AutoSize = true;
            this.lbl_Alt_Contact_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Alt_Contact_No.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Alt_Contact_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Alt_Contact_No.Location = new System.Drawing.Point(26, 218);
            this.lbl_Alt_Contact_No.Name = "lbl_Alt_Contact_No";
            this.lbl_Alt_Contact_No.Size = new System.Drawing.Size(147, 37);
            this.lbl_Alt_Contact_No.TabIndex = 22;
            this.lbl_Alt_Contact_No.Text = "Alt. Contact No.";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(26, 150);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(106, 37);
            this.lbl_Mobile_No.TabIndex = 22;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Dealer_ID
            // 
            this.lbl_Dealer_ID.AutoSize = true;
            this.lbl_Dealer_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Dealer_ID.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dealer_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Dealer_ID.Location = new System.Drawing.Point(26, 26);
            this.lbl_Dealer_ID.Name = "lbl_Dealer_ID";
            this.lbl_Dealer_ID.Size = new System.Drawing.Size(94, 37);
            this.lbl_Dealer_ID.TabIndex = 21;
            this.lbl_Dealer_ID.Text = "Dealer ID";
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(462, 26);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(111, 37);
            this.lbl_Tie_Up_Date.TabIndex = 20;
            this.lbl_Tie_Up_Date.Text = "Tie Up Date";
            // 
            // frm_Add_New_Dealer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.ControlBox = false;
            this.Controls.Add(this.gb_Dealer_Details);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.pnl_Header);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Dealer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Dealer";
            this.Load += new System.EventHandler(this.frm_Add_New_Dealer_Load);
            this.pnl_Header.ResumeLayout(false);
            this.pnl_Header.PerformLayout();
            this.gb_Dealer_Details.ResumeLayout(false);
            this.gb_Dealer_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel pnl_Header;
        private System.Windows.Forms.GroupBox gb_Dealer_Details;
        private System.Windows.Forms.Button btn_Browse_Docs;
        private System.Windows.Forms.DateTimePicker dtp_Tie_Up_Date;
        private System.Windows.Forms.TextBox tb_Bank_Details;
        private System.Windows.Forms.TextBox tb_PAN_No;
        private System.Windows.Forms.TextBox tb_Udyam_Adhaar_No;
        private System.Windows.Forms.TextBox tb_Alt_Contact_No;
        private System.Windows.Forms.TextBox tb_Mob_No;
        private System.Windows.Forms.TextBox tb_Dealer_Name;
        private System.Windows.Forms.TextBox tb_Dealer_ID;
        private System.Windows.Forms.Label lbl_Dealer_Name;
        private System.Windows.Forms.Label lbl_Bank_Details;
        private System.Windows.Forms.Label lbl_PAN_No;
        private System.Windows.Forms.Label lbl_Udyam_Adhaar_No;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.Label lbl_Office_Address;
        private System.Windows.Forms.Label lbl_Alt_Contact_No;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Dealer_ID;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.TextBox tb_Office_Address;
    }
}