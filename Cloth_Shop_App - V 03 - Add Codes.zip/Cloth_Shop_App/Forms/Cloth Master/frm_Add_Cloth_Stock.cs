﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Cloth
{
    public partial class frm_Add_Cloth_Stock : Form
    {
        public frm_Add_Cloth_Stock()
        {
            InitializeComponent();
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == '.'))
            {
                e.Handled = true;
            }
        }
        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == (char)Keys.Space) || (e.KeyChar == (char)Keys.ShiftKey) || (e.KeyChar == (char)Keys.CapsLock)))
            {
                e.Handled = true;
            }
        }
        void Clear_Controls()
        {
            cmb_Category.SelectedIndex = -1;
            cmb_Cloth_Type.SelectedIndex = -1;
            cmb_Cloth_Name.SelectedIndex = -1;

            tb_Cloth_ID.Clear();
            tb_Current_Stock.Clear();
            tb_New_Stock.Clear();
        }
        private void frm_Add_Cloth_Stock_Load(object sender, EventArgs e)
        {
            Clear_Controls();
            cmb_Category.Focus();
        }
        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            cmb_Category.Focus();
        }
        private void cmb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_ComboBox("Cloth_Type", cmb_Cloth_Type, "Select Cloth_Type from Cloth_Type_Details where Cloth_Category = '" + cmb_Category.Text + "'");
        }
        private void cmb_Cloth_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_ComboBox("Cloth_Name", cmb_Cloth_Name, "Select Cloth_Name from Cloth_Details where Category = '" + cmb_Category.Text + "' And Cloth_Type = '" + cmb_Cloth_Type.Text + "'");
        }
        private void cmb_Cloth_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Con_Open();

            SqlCommand Cmd = new SqlCommand("Select Cloth_ID, Current_Stock From Cloth_Details where Category = '" + cmb_Category.Text + "' And Cloth_Type = '" + cmb_Cloth_Type.Text + "' And Cloth_Name = '" + cmb_Cloth_Name.Text + "'  ", Shared_Content.Con);

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Cloth_ID.Text = (Dr["Cloth_ID"].ToString());
                tb_Current_Stock.Text = (Dr["Current_Stock"].ToString());
            }

            Cmd.Dispose();
            Dr.Close();
            Shared_Content.Con_Close();
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            Shared_Content.Con_Open();

            if (tb_Cloth_ID.Text != "" && tb_Current_Stock.Text != "" && tb_New_Stock.Text != "")
            {
                SqlCommand cmd = new SqlCommand();

                cmd.CommandText = "Insert Into Stock_Updates Values (@ID, @SDate ,@SAdd, @SReceiver) ";
                cmd.Connection = Shared_Content.Con;

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = tb_Cloth_ID.Text;
                cmd.Parameters.Add("@SDate", SqlDbType.Date).Value = System.DateTime.Today.Date;
                cmd.Parameters.Add("@SAdd", SqlDbType.Int).Value = tb_New_Stock.Text;
                cmd.Parameters.Add("@SReceiver", SqlDbType.NVarChar).Value = Shared_Content.LoggedInUName;

                cmd.ExecuteNonQuery();
                cmd.Dispose();

                cmd.CommandText = "Update Cloth_Details Set Current_Stock = @CStock Where Cloth_ID = @CID ";
                cmd.Connection = Shared_Content.Con;

                cmd.Parameters.Add("@CID", SqlDbType.Int).Value = tb_Cloth_ID.Text;
                cmd.Parameters.Add("@CStock", SqlDbType.Int).Value = Convert.ToInt32(tb_Current_Stock.Text) + Convert.ToInt32(tb_New_Stock.Text);

                cmd.ExecuteNonQuery();
                cmd.Dispose();

                MessageBox.Show("Stock Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("1st Fill All The Fields!!!", "Fill Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            Shared_Content.Con_Close();
        }
    }
}
