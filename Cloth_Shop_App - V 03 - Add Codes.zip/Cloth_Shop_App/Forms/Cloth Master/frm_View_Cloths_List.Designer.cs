﻿namespace Cloth_Shop_App.Forms.Cloth_Master
{
    partial class frm_View_Cloths_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Header = new System.Windows.Forms.Panel();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.dgv_Cloths_List = new System.Windows.Forms.DataGridView();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.cmb_Cloth_Type = new System.Windows.Forms.ComboBox();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.lbl_Cloth_Name = new System.Windows.Forms.Label();
            this.cmb_Cloth_Name = new System.Windows.Forms.ComboBox();
            this.pnl_Header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cloths_List)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_Header
            // 
            this.pnl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Header.Controls.Add(this.lbl_Header);
            this.pnl_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Header.Location = new System.Drawing.Point(0, 0);
            this.pnl_Header.Name = "pnl_Header";
            this.pnl_Header.Size = new System.Drawing.Size(884, 92);
            this.pnl_Header.TabIndex = 23;
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LawnGreen;
            this.lbl_Header.Location = new System.Drawing.Point(310, 22);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(235, 45);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Cloths List";
            // 
            // dgv_Cloths_List
            // 
            this.dgv_Cloths_List.AllowUserToAddRows = false;
            this.dgv_Cloths_List.AllowUserToDeleteRows = false;
            this.dgv_Cloths_List.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Cloths_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Cloths_List.Location = new System.Drawing.Point(12, 187);
            this.dgv_Cloths_List.Name = "dgv_Cloths_List";
            this.dgv_Cloths_List.ReadOnly = true;
            this.dgv_Cloths_List.Size = new System.Drawing.Size(860, 371);
            this.dgv_Cloths_List.TabIndex = 4;
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(311, 126);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(106, 37);
            this.lbl_Cloth_Type.TabIndex = 28;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // cmb_Cloth_Type
            // 
            this.cmb_Cloth_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Type.FormattingEnabled = true;
            this.cmb_Cloth_Type.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Type.Location = new System.Drawing.Point(434, 127);
            this.cmb_Cloth_Type.Name = "cmb_Cloth_Type";
            this.cmb_Cloth_Type.Size = new System.Drawing.Size(135, 31);
            this.cmb_Cloth_Type.TabIndex = 2;
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(135, 127);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(135, 31);
            this.cmb_Category.TabIndex = 1;
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(21, 126);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(88, 37);
            this.lbl_Category_Name.TabIndex = 27;
            this.lbl_Category_Name.Text = "Category";
            // 
            // lbl_Cloth_Name
            // 
            this.lbl_Cloth_Name.AutoSize = true;
            this.lbl_Cloth_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Name.Location = new System.Drawing.Point(601, 126);
            this.lbl_Cloth_Name.Name = "lbl_Cloth_Name";
            this.lbl_Cloth_Name.Size = new System.Drawing.Size(114, 37);
            this.lbl_Cloth_Name.TabIndex = 30;
            this.lbl_Cloth_Name.Text = "Cloth Name";
            // 
            // cmb_Cloth_Name
            // 
            this.cmb_Cloth_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Name.FormattingEnabled = true;
            this.cmb_Cloth_Name.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Name.Location = new System.Drawing.Point(728, 127);
            this.cmb_Cloth_Name.Name = "cmb_Cloth_Name";
            this.cmb_Cloth_Name.Size = new System.Drawing.Size(135, 31);
            this.cmb_Cloth_Name.TabIndex = 3;
            // 
            // frm_View_Cloths_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.lbl_Cloth_Name);
            this.Controls.Add(this.cmb_Cloth_Name);
            this.Controls.Add(this.lbl_Cloth_Type);
            this.Controls.Add(this.cmb_Cloth_Type);
            this.Controls.Add(this.cmb_Category);
            this.Controls.Add(this.lbl_Category_Name);
            this.Controls.Add(this.pnl_Header);
            this.Controls.Add(this.dgv_Cloths_List);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_View_Cloths_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Cloths List";
            this.pnl_Header.ResumeLayout(false);
            this.pnl_Header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cloths_List)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Header;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.DataGridView dgv_Cloths_List;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.Label lbl_Cloth_Name;
        private System.Windows.Forms.ComboBox cmb_Cloth_Name;
    }
}