﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Cloth
{
    public partial class frm_Add_Cloth : Form
    {
        public frm_Add_Cloth()
        {
            InitializeComponent();
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == (char)Keys.Space) || (e.KeyChar == (char)Keys.ShiftKey) || (e.KeyChar == (char)Keys.CapsLock)))
            {
                e.Handled = true;
            }
        }

        void Clear_Controls()
        {
            tb_Cloth_ID.Text = Convert.ToString(Shared_Content.Auto_Incr("Cloth_Details", "Cloth_ID", 501));

            tb_Cloth_Name.Clear();
            tb_Purchase_Price.Clear();
            tb_Sales_Price.Clear();
            tb_Cloth_Details.Clear();
            cmb_Category.SelectedIndex = -1;
            cmb_Cloth_Type.SelectedIndex = -1;
            cmb_Dealer_Name.SelectedIndex = -1;
        }
        private void frm_Add_Cloth_Load(object sender, EventArgs e)
        {
            Clear_Controls();
            cmb_Category.Focus();
            Shared_Content.Bind_ComboBox("Staff_Name", cmb_Dealer_Name, "Select Staff_Name from Staff_Details");
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            cmb_Category.Focus();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Shared_Content.Con_Open();

            if (tb_Cloth_Name.Text != "" && cmb_Category.Text != "" && cmb_Cloth_Type.Text != "" && tb_Purchase_Price.Text != "" && tb_Sales_Price.Text != "" && cmb_Dealer_Name.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Insert Into Cloth_Details Values (@ID, @Cat, @CType, @Name, @PPrice, @SPrice, @CStock, @DName, @ClothDetails) ", Shared_Content.Con);

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = tb_Cloth_ID.Text;
                cmd.Parameters.Add("@Cat", SqlDbType.NVarChar).Value = cmb_Category.Text;
                cmd.Parameters.Add("@CType", SqlDbType.NVarChar).Value = cmb_Cloth_Type.Text;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = tb_Cloth_Name.Text;
                cmd.Parameters.Add("@PPrice", SqlDbType.Money).Value = tb_Purchase_Price.Text;
                cmd.Parameters.Add("@SPrice", SqlDbType.Money).Value = tb_Sales_Price.Text;
                cmd.Parameters.Add("@CStock", SqlDbType.Int).Value = "0";
                cmd.Parameters.Add("@DName", SqlDbType.NVarChar).Value = cmb_Dealer_Name.Text;
                cmd.Parameters.Add("@ClothDetails", SqlDbType.NVarChar).Value = tb_Cloth_Details.Text;

                cmd.ExecuteNonQuery();

                MessageBox.Show("Cloth Details Saved Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("1st Fill All The Fields!!!", "Fill Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            Shared_Content.Con_Close();
        }

        private void cmb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_ComboBox("Cloth_Type", cmb_Cloth_Type, "Select Cloth_Type from Cloth_Type_Details where Cloth_Category = '" + cmb_Category.Text + "'");
        }
    }
}
