﻿namespace Cloth_Shop_App.Forms.Cloth
{
    partial class frm_Add_Cloth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Header = new System.Windows.Forms.Panel();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.tb_Cloth_ID = new System.Windows.Forms.TextBox();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.lbl_Cloth_ID = new System.Windows.Forms.Label();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.gb_Cloth_Type_Details = new System.Windows.Forms.GroupBox();
            this.tb_Cloth_Details = new System.Windows.Forms.TextBox();
            this.tb_Sales_Price = new System.Windows.Forms.TextBox();
            this.tb_Purchase_Price = new System.Windows.Forms.TextBox();
            this.tb_Cloth_Name = new System.Windows.Forms.TextBox();
            this.lbl_Dealer_Name = new System.Windows.Forms.Label();
            this.lbl_Cloth_Details = new System.Windows.Forms.Label();
            this.lbl_Sales_Price = new System.Windows.Forms.Label();
            this.lbl_Puchase_Price = new System.Windows.Forms.Label();
            this.lbl_Cloth_Name = new System.Windows.Forms.Label();
            this.cmb_Dealer_Name = new System.Windows.Forms.ComboBox();
            this.cmb_Cloth_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.pnl_Header.SuspendLayout();
            this.gb_Cloth_Type_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Header
            // 
            this.pnl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Header.Controls.Add(this.lbl_Header);
            this.pnl_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Header.Location = new System.Drawing.Point(0, 0);
            this.pnl_Header.Name = "pnl_Header";
            this.pnl_Header.Size = new System.Drawing.Size(884, 92);
            this.pnl_Header.TabIndex = 14;
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LawnGreen;
            this.lbl_Header.Location = new System.Drawing.Point(290, 24);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(327, 45);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Cloth";
            // 
            // tb_Cloth_ID
            // 
            this.tb_Cloth_ID.Enabled = false;
            this.tb_Cloth_ID.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Cloth_ID.Location = new System.Drawing.Point(192, 27);
            this.tb_Cloth_ID.MaxLength = 5;
            this.tb_Cloth_ID.Name = "tb_Cloth_ID";
            this.tb_Cloth_ID.Size = new System.Drawing.Size(195, 32);
            this.tb_Cloth_ID.TabIndex = 1;
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(26, 182);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(106, 37);
            this.lbl_Cloth_Type.TabIndex = 22;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // lbl_Cloth_ID
            // 
            this.lbl_Cloth_ID.AutoSize = true;
            this.lbl_Cloth_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_ID.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_ID.Location = new System.Drawing.Point(26, 26);
            this.lbl_Cloth_ID.Name = "lbl_Cloth_ID";
            this.lbl_Cloth_ID.Size = new System.Drawing.Size(89, 37);
            this.lbl_Cloth_ID.TabIndex = 21;
            this.lbl_Cloth_ID.Text = "Cloth ID";
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(192, 102);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(195, 31);
            this.cmb_Category.TabIndex = 2;
            this.cmb_Category.SelectedIndexChanged += new System.EventHandler(this.cmb_Category_SelectedIndexChanged);
            // 
            // gb_Cloth_Type_Details
            // 
            this.gb_Cloth_Type_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_Cloth_Details);
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_Sales_Price);
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_Purchase_Price);
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_Cloth_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_Cloth_ID);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Dealer_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_Details);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Sales_Price);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Puchase_Price);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_Type);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_ID);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Dealer_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Cloth_Type);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Category);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Category_Name);
            this.gb_Cloth_Type_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Cloth_Type_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Cloth_Type_Details.Location = new System.Drawing.Point(13, 106);
            this.gb_Cloth_Type_Details.Name = "gb_Cloth_Type_Details";
            this.gb_Cloth_Type_Details.Size = new System.Drawing.Size(859, 370);
            this.gb_Cloth_Type_Details.TabIndex = 15;
            this.gb_Cloth_Type_Details.TabStop = false;
            this.gb_Cloth_Type_Details.Text = "Cloth Details";
            // 
            // tb_Cloth_Details
            // 
            this.tb_Cloth_Details.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Cloth_Details.Location = new System.Drawing.Point(637, 265);
            this.tb_Cloth_Details.MaxLength = 120;
            this.tb_Cloth_Details.Multiline = true;
            this.tb_Cloth_Details.Name = "tb_Cloth_Details";
            this.tb_Cloth_Details.Size = new System.Drawing.Size(195, 75);
            this.tb_Cloth_Details.TabIndex = 8;
            // 
            // tb_Sales_Price
            // 
            this.tb_Sales_Price.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Sales_Price.Location = new System.Drawing.Point(637, 183);
            this.tb_Sales_Price.MaxLength = 7;
            this.tb_Sales_Price.Name = "tb_Sales_Price";
            this.tb_Sales_Price.Size = new System.Drawing.Size(195, 32);
            this.tb_Sales_Price.TabIndex = 7;
            // 
            // tb_Purchase_Price
            // 
            this.tb_Purchase_Price.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Purchase_Price.Location = new System.Drawing.Point(637, 102);
            this.tb_Purchase_Price.MaxLength = 7;
            this.tb_Purchase_Price.Name = "tb_Purchase_Price";
            this.tb_Purchase_Price.Size = new System.Drawing.Size(195, 32);
            this.tb_Purchase_Price.TabIndex = 6;
            // 
            // tb_Cloth_Name
            // 
            this.tb_Cloth_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Cloth_Name.Location = new System.Drawing.Point(192, 265);
            this.tb_Cloth_Name.MaxLength = 80;
            this.tb_Cloth_Name.Name = "tb_Cloth_Name";
            this.tb_Cloth_Name.Size = new System.Drawing.Size(195, 32);
            this.tb_Cloth_Name.TabIndex = 4;
            // 
            // lbl_Dealer_Name
            // 
            this.lbl_Dealer_Name.AutoSize = true;
            this.lbl_Dealer_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Dealer_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dealer_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Dealer_Name.Location = new System.Drawing.Point(471, 22);
            this.lbl_Dealer_Name.Name = "lbl_Dealer_Name";
            this.lbl_Dealer_Name.Size = new System.Drawing.Size(119, 37);
            this.lbl_Dealer_Name.TabIndex = 22;
            this.lbl_Dealer_Name.Text = "Dealer Name";
            // 
            // lbl_Cloth_Details
            // 
            this.lbl_Cloth_Details.AutoSize = true;
            this.lbl_Cloth_Details.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Details.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Details.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Details.Location = new System.Drawing.Point(471, 264);
            this.lbl_Cloth_Details.Name = "lbl_Cloth_Details";
            this.lbl_Cloth_Details.Size = new System.Drawing.Size(121, 37);
            this.lbl_Cloth_Details.TabIndex = 22;
            this.lbl_Cloth_Details.Text = "Cloth Details";
            // 
            // lbl_Sales_Price
            // 
            this.lbl_Sales_Price.AutoSize = true;
            this.lbl_Sales_Price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Sales_Price.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sales_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Sales_Price.Location = new System.Drawing.Point(471, 182);
            this.lbl_Sales_Price.Name = "lbl_Sales_Price";
            this.lbl_Sales_Price.Size = new System.Drawing.Size(98, 37);
            this.lbl_Sales_Price.TabIndex = 22;
            this.lbl_Sales_Price.Text = "Sales Price";
            // 
            // lbl_Puchase_Price
            // 
            this.lbl_Puchase_Price.AutoSize = true;
            this.lbl_Puchase_Price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Puchase_Price.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Puchase_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Puchase_Price.Location = new System.Drawing.Point(471, 101);
            this.lbl_Puchase_Price.Name = "lbl_Puchase_Price";
            this.lbl_Puchase_Price.Size = new System.Drawing.Size(130, 37);
            this.lbl_Puchase_Price.TabIndex = 22;
            this.lbl_Puchase_Price.Text = "Purchase Price";
            // 
            // lbl_Cloth_Name
            // 
            this.lbl_Cloth_Name.AutoSize = true;
            this.lbl_Cloth_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Name.Location = new System.Drawing.Point(26, 264);
            this.lbl_Cloth_Name.Name = "lbl_Cloth_Name";
            this.lbl_Cloth_Name.Size = new System.Drawing.Size(114, 37);
            this.lbl_Cloth_Name.TabIndex = 22;
            this.lbl_Cloth_Name.Text = "Cloth Name";
            // 
            // cmb_Dealer_Name
            // 
            this.cmb_Dealer_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Dealer_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Dealer_Name.FormattingEnabled = true;
            this.cmb_Dealer_Name.Location = new System.Drawing.Point(637, 23);
            this.cmb_Dealer_Name.Name = "cmb_Dealer_Name";
            this.cmb_Dealer_Name.Size = new System.Drawing.Size(195, 31);
            this.cmb_Dealer_Name.TabIndex = 5;
            // 
            // cmb_Cloth_Type
            // 
            this.cmb_Cloth_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Type.FormattingEnabled = true;
            this.cmb_Cloth_Type.Location = new System.Drawing.Point(192, 183);
            this.cmb_Cloth_Type.Name = "cmb_Cloth_Type";
            this.cmb_Cloth_Type.Size = new System.Drawing.Size(195, 31);
            this.cmb_Cloth_Type.TabIndex = 3;
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(26, 102);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(88, 37);
            this.lbl_Category_Name.TabIndex = 20;
            this.lbl_Category_Name.Text = "Category";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Save.Location = new System.Drawing.Point(570, 500);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(137, 47);
            this.btn_Save.TabIndex = 9;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(220, 500);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(150, 47);
            this.btn_Refresh.TabIndex = 10;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Add_Cloth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.ControlBox = false;
            this.Controls.Add(this.pnl_Header);
            this.Controls.Add(this.gb_Cloth_Type_Details);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_Cloth";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Cloth";
            this.Load += new System.EventHandler(this.frm_Add_Cloth_Load);
            this.pnl_Header.ResumeLayout(false);
            this.pnl_Header.PerformLayout();
            this.gb_Cloth_Type_Details.ResumeLayout(false);
            this.gb_Cloth_Type_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Header;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.TextBox tb_Cloth_ID;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.Label lbl_Cloth_ID;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.GroupBox gb_Cloth_Type_Details;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Sales_Price;
        private System.Windows.Forms.TextBox tb_Purchase_Price;
        private System.Windows.Forms.TextBox tb_Cloth_Name;
        private System.Windows.Forms.Label lbl_Dealer_Name;
        private System.Windows.Forms.Label lbl_Sales_Price;
        private System.Windows.Forms.Label lbl_Puchase_Price;
        private System.Windows.Forms.Label lbl_Cloth_Name;
        private System.Windows.Forms.ComboBox cmb_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Dealer_Name;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.TextBox tb_Cloth_Details;
        private System.Windows.Forms.Label lbl_Cloth_Details;
    }
}