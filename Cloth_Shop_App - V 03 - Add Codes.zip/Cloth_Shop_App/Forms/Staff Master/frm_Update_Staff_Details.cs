﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Staff_Master
{
    public partial class frm_Update_Staff_Details : Form
    {
        public frm_Update_Staff_Details()
        {
            InitializeComponent();
        }
    }
}
