﻿namespace Cloth_Shop_App.Forms.Staff_Master
{
    partial class frm_Update_Staff_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Header = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.gb_Staff_Details = new System.Windows.Forms.GroupBox();
            this.pnl_Header = new System.Windows.Forms.Panel();
            this.pnl_Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LawnGreen;
            this.lbl_Header.Location = new System.Drawing.Point(263, 29);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(420, 45);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Update Staff Details";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(220, 510);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(150, 47);
            this.btn_Refresh.TabIndex = 21;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Update.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Update.Location = new System.Drawing.Point(570, 510);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(137, 47);
            this.btn_Update.TabIndex = 20;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            // 
            // gb_Staff_Details
            // 
            this.gb_Staff_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Staff_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Staff_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Staff_Details.Location = new System.Drawing.Point(13, 102);
            this.gb_Staff_Details.Name = "gb_Staff_Details";
            this.gb_Staff_Details.Size = new System.Drawing.Size(859, 388);
            this.gb_Staff_Details.TabIndex = 23;
            this.gb_Staff_Details.TabStop = false;
            this.gb_Staff_Details.Text = "Staff Details";
            // 
            // pnl_Header
            // 
            this.pnl_Header.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Header.Controls.Add(this.lbl_Header);
            this.pnl_Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Header.Location = new System.Drawing.Point(0, 0);
            this.pnl_Header.Name = "pnl_Header";
            this.pnl_Header.Size = new System.Drawing.Size(884, 92);
            this.pnl_Header.TabIndex = 22;
            // 
            // frm_Update_Staff_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.gb_Staff_Details);
            this.Controls.Add(this.pnl_Header);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Update_Staff_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Staff Details";
            this.pnl_Header.ResumeLayout(false);
            this.pnl_Header.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.GroupBox gb_Staff_Details;
        private System.Windows.Forms.Panel pnl_Header;
    }
}