﻿namespace Cloth_Shop_App.Forms.Customer_Master
{
    partial class frm_Add_New_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gb_Customer_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Bill_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.tb_Mob_No = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.tb_Cloth_ID = new System.Windows.Forms.TextBox();
            this.lbl_Customer_ID = new System.Windows.Forms.Label();
            this.tb_Customer_Name = new System.Windows.Forms.TextBox();
            this.lbl_Customer_Name = new System.Windows.Forms.Label();
            this.tb_Cloth_Details = new System.Windows.Forms.TextBox();
            this.tb_Sales_Price = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.lbl_Total_Bill = new System.Windows.Forms.Label();
            this.lbl_Sales_Price = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.cmb_Cloth_Type = new System.Windows.Forms.ComboBox();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.gb_Purchase = new System.Windows.Forms.GroupBox();
            this.dgv_Customer_List = new System.Windows.Forms.DataGridView();
            this.Sr_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cloth_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cloth_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sales_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_Cloth_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Qty = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_GST = new System.Windows.Forms.Label();
            this.tb_GST = new System.Windows.Forms.TextBox();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.tb_Discount = new System.Windows.Forms.TextBox();
            this.lbl_T1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Final_Bill = new System.Windows.Forms.Label();
            this.tb_Final_Bill = new System.Windows.Forms.TextBox();
            this.gb_Customer_Details.SuspendLayout();
            this.gb_Purchase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Customer_List)).BeginInit();
            this.SuspendLayout();
            // 
            // gb_Customer_Details
            // 
            this.gb_Customer_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Customer_Details.Controls.Add(this.dtp_Bill_Date);
            this.gb_Customer_Details.Controls.Add(this.lbl_Tie_Up_Date);
            this.gb_Customer_Details.Controls.Add(this.tb_Mob_No);
            this.gb_Customer_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Customer_Details.Controls.Add(this.tb_Cloth_ID);
            this.gb_Customer_Details.Controls.Add(this.lbl_Customer_ID);
            this.gb_Customer_Details.Controls.Add(this.tb_Customer_Name);
            this.gb_Customer_Details.Controls.Add(this.lbl_Customer_Name);
            this.gb_Customer_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Customer_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Customer_Details.Location = new System.Drawing.Point(13, 7);
            this.gb_Customer_Details.Name = "gb_Customer_Details";
            this.gb_Customer_Details.Size = new System.Drawing.Size(859, 102);
            this.gb_Customer_Details.TabIndex = 21;
            this.gb_Customer_Details.TabStop = false;
            this.gb_Customer_Details.Text = "Customer Details";
            // 
            // dtp_Bill_Date
            // 
            this.dtp_Bill_Date.Enabled = false;
            this.dtp_Bill_Date.Font = new System.Drawing.Font("Mongolian Baiti", 11F);
            this.dtp_Bill_Date.Location = new System.Drawing.Point(616, 18);
            this.dtp_Bill_Date.Name = "dtp_Bill_Date";
            this.dtp_Bill_Date.Size = new System.Drawing.Size(185, 24);
            this.dtp_Bill_Date.TabIndex = 2;
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(455, 14);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(72, 32);
            this.lbl_Tie_Up_Date.TabIndex = 26;
            this.lbl_Tie_Up_Date.Text = "Bill Date";
            // 
            // tb_Mob_No
            // 
            this.tb_Mob_No.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Mob_No.Location = new System.Drawing.Point(616, 58);
            this.tb_Mob_No.MaxLength = 10;
            this.tb_Mob_No.Name = "tb_Mob_No";
            this.tb_Mob_No.Size = new System.Drawing.Size(185, 29);
            this.tb_Mob_No.TabIndex = 4;
            this.tb_Mob_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(455, 58);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(89, 32);
            this.lbl_Mobile_No.TabIndex = 24;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // tb_Cloth_ID
            // 
            this.tb_Cloth_ID.Enabled = false;
            this.tb_Cloth_ID.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Cloth_ID.Location = new System.Drawing.Point(159, 17);
            this.tb_Cloth_ID.MaxLength = 5;
            this.tb_Cloth_ID.Name = "tb_Cloth_ID";
            this.tb_Cloth_ID.Size = new System.Drawing.Size(195, 29);
            this.tb_Cloth_ID.TabIndex = 1;
            // 
            // lbl_Customer_ID
            // 
            this.lbl_Customer_ID.AutoSize = true;
            this.lbl_Customer_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Customer_ID.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Customer_ID.Location = new System.Drawing.Point(20, 18);
            this.lbl_Customer_ID.Name = "lbl_Customer_ID";
            this.lbl_Customer_ID.Size = new System.Drawing.Size(103, 32);
            this.lbl_Customer_ID.TabIndex = 21;
            this.lbl_Customer_ID.Text = "Customer ID";
            // 
            // tb_Customer_Name
            // 
            this.tb_Customer_Name.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Customer_Name.Location = new System.Drawing.Point(159, 58);
            this.tb_Customer_Name.MaxLength = 80;
            this.tb_Customer_Name.Name = "tb_Customer_Name";
            this.tb_Customer_Name.Size = new System.Drawing.Size(195, 29);
            this.tb_Customer_Name.TabIndex = 3;
            this.tb_Customer_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Customer_Name
            // 
            this.lbl_Customer_Name.AutoSize = true;
            this.lbl_Customer_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Customer_Name.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Customer_Name.Location = new System.Drawing.Point(20, 58);
            this.lbl_Customer_Name.Name = "lbl_Customer_Name";
            this.lbl_Customer_Name.Size = new System.Drawing.Size(124, 32);
            this.lbl_Customer_Name.TabIndex = 22;
            this.lbl_Customer_Name.Text = "Customer Name";
            // 
            // tb_Cloth_Details
            // 
            this.tb_Cloth_Details.Enabled = false;
            this.tb_Cloth_Details.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Cloth_Details.Location = new System.Drawing.Point(112, 383);
            this.tb_Cloth_Details.MaxLength = 7;
            this.tb_Cloth_Details.Name = "tb_Cloth_Details";
            this.tb_Cloth_Details.Size = new System.Drawing.Size(146, 29);
            this.tb_Cloth_Details.TabIndex = 12;
            // 
            // tb_Sales_Price
            // 
            this.tb_Sales_Price.Enabled = false;
            this.tb_Sales_Price.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Sales_Price.Location = new System.Drawing.Point(360, 59);
            this.tb_Sales_Price.MaxLength = 7;
            this.tb_Sales_Price.Name = "tb_Sales_Price";
            this.tb_Sales_Price.Size = new System.Drawing.Size(163, 29);
            this.tb_Sales_Price.TabIndex = 9;
            this.tb_Sales_Price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Total
            // 
            this.tb_Total.Enabled = false;
            this.tb_Total.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Total.Location = new System.Drawing.Point(647, 56);
            this.tb_Total.MaxLength = 7;
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.Size = new System.Drawing.Size(179, 29);
            this.tb_Total.TabIndex = 10;
            // 
            // lbl_Total_Bill
            // 
            this.lbl_Total_Bill.AutoSize = true;
            this.lbl_Total_Bill.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Bill.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Bill.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Total_Bill.Location = new System.Drawing.Point(27, 383);
            this.lbl_Total_Bill.Name = "lbl_Total_Bill";
            this.lbl_Total_Bill.Size = new System.Drawing.Size(74, 32);
            this.lbl_Total_Bill.TabIndex = 22;
            this.lbl_Total_Bill.Text = "Total Bill";
            // 
            // lbl_Sales_Price
            // 
            this.lbl_Sales_Price.AutoSize = true;
            this.lbl_Sales_Price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Sales_Price.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sales_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Sales_Price.Location = new System.Drawing.Point(255, 60);
            this.lbl_Sales_Price.Name = "lbl_Sales_Price";
            this.lbl_Sales_Price.Size = new System.Drawing.Size(83, 32);
            this.lbl_Sales_Price.TabIndex = 22;
            this.lbl_Sales_Price.Text = "Sales Price";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Total.Location = new System.Drawing.Point(561, 58);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(48, 32);
            this.lbl_Total.TabIndex = 22;
            this.lbl_Total.Text = "Total";
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(255, 18);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(90, 32);
            this.lbl_Cloth_Type.TabIndex = 22;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // cmb_Cloth_Type
            // 
            this.cmb_Cloth_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 15F);
            this.cmb_Cloth_Type.FormattingEnabled = true;
            this.cmb_Cloth_Type.Location = new System.Drawing.Point(360, 18);
            this.cmb_Cloth_Type.Name = "cmb_Cloth_Type";
            this.cmb_Cloth_Type.Size = new System.Drawing.Size(163, 29);
            this.cmb_Cloth_Type.TabIndex = 6;
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 15F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(105, 18);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(125, 29);
            this.cmb_Category.TabIndex = 5;
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(6, 18);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(75, 32);
            this.lbl_Category_Name.TabIndex = 20;
            this.lbl_Category_Name.Text = "Category";
            // 
            // gb_Purchase
            // 
            this.gb_Purchase.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Purchase.Controls.Add(this.dgv_Customer_List);
            this.gb_Purchase.Controls.Add(this.textBox1);
            this.gb_Purchase.Controls.Add(this.tb_Total);
            this.gb_Purchase.Controls.Add(this.btn_Add);
            this.gb_Purchase.Controls.Add(this.label2);
            this.gb_Purchase.Controls.Add(this.tb_Sales_Price);
            this.gb_Purchase.Controls.Add(this.cmb_Cloth_Name);
            this.gb_Purchase.Controls.Add(this.lbl_Qty);
            this.gb_Purchase.Controls.Add(this.lbl_Total);
            this.gb_Purchase.Controls.Add(this.lbl_Category_Name);
            this.gb_Purchase.Controls.Add(this.cmb_Category);
            this.gb_Purchase.Controls.Add(this.lbl_Sales_Price);
            this.gb_Purchase.Controls.Add(this.lbl_Cloth_Type);
            this.gb_Purchase.Controls.Add(this.cmb_Cloth_Type);
            this.gb_Purchase.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Purchase.ForeColor = System.Drawing.Color.Black;
            this.gb_Purchase.Location = new System.Drawing.Point(13, 117);
            this.gb_Purchase.Name = "gb_Purchase";
            this.gb_Purchase.Size = new System.Drawing.Size(859, 251);
            this.gb_Purchase.TabIndex = 22;
            this.gb_Purchase.TabStop = false;
            this.gb_Purchase.Text = "Purchase Details";
            // 
            // dgv_Customer_List
            // 
            this.dgv_Customer_List.AllowUserToAddRows = false;
            this.dgv_Customer_List.AllowUserToDeleteRows = false;
            this.dgv_Customer_List.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Lucida Bright", 7F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Customer_List.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Customer_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Customer_List.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Sr_No,
            this.Category,
            this.Cloth_Type,
            this.Cloth_Name,
            this.Qty,
            this.Sales_Price,
            this.Total});
            this.dgv_Customer_List.Location = new System.Drawing.Point(78, 99);
            this.dgv_Customer_List.Name = "dgv_Customer_List";
            this.dgv_Customer_List.ReadOnly = true;
            this.dgv_Customer_List.Size = new System.Drawing.Size(775, 142);
            this.dgv_Customer_List.TabIndex = 25;
            // 
            // Sr_No
            // 
            this.Sr_No.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Sr_No.HeaderText = "Sr.No.";
            this.Sr_No.Name = "Sr_No";
            this.Sr_No.ReadOnly = true;
            this.Sr_No.Width = 61;
            // 
            // Category
            // 
            this.Category.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Category.HeaderText = "Category";
            this.Category.Name = "Category";
            this.Category.ReadOnly = true;
            this.Category.Width = 79;
            // 
            // Cloth_Type
            // 
            this.Cloth_Type.HeaderText = "Cloth Type";
            this.Cloth_Type.Name = "Cloth_Type";
            this.Cloth_Type.ReadOnly = true;
            // 
            // Cloth_Name
            // 
            this.Cloth_Name.HeaderText = "Cloth Name";
            this.Cloth_Name.Name = "Cloth_Name";
            this.Cloth_Name.ReadOnly = true;
            // 
            // Qty
            // 
            this.Qty.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Qty.HeaderText = "Quantity";
            this.Qty.Name = "Qty";
            this.Qty.ReadOnly = true;
            this.Qty.Width = 76;
            // 
            // Sales_Price
            // 
            this.Sales_Price.HeaderText = "Sales Price";
            this.Sales_Price.Name = "Sales_Price";
            this.Sales_Price.ReadOnly = true;
            // 
            // Total
            // 
            this.Total.HeaderText = "Total";
            this.Total.Name = "Total";
            this.Total.ReadOnly = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.textBox1.Location = new System.Drawing.Point(105, 60);
            this.textBox1.MaxLength = 5;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 29);
            this.textBox1.TabIndex = 8;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Add.Font = new System.Drawing.Font("Microsoft Himalaya", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.Cyan;
            this.btn_Add.Location = new System.Drawing.Point(6, 131);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(66, 70);
            this.btn_Add.TabIndex = 11;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(545, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 32);
            this.label2.TabIndex = 24;
            this.label2.Text = "Cloth Name";
            // 
            // cmb_Cloth_Name
            // 
            this.cmb_Cloth_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Name.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.cmb_Cloth_Name.FormattingEnabled = true;
            this.cmb_Cloth_Name.Items.AddRange(new object[] {
            "Gents",
            "Kids",
            "Ladies"});
            this.cmb_Cloth_Name.Location = new System.Drawing.Point(647, 19);
            this.cmb_Cloth_Name.Name = "cmb_Cloth_Name";
            this.cmb_Cloth_Name.Size = new System.Drawing.Size(179, 28);
            this.cmb_Cloth_Name.TabIndex = 7;
            // 
            // lbl_Qty
            // 
            this.lbl_Qty.AutoSize = true;
            this.lbl_Qty.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Qty.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Qty.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Qty.Location = new System.Drawing.Point(6, 59);
            this.lbl_Qty.Name = "lbl_Qty";
            this.lbl_Qty.Size = new System.Drawing.Size(74, 32);
            this.lbl_Qty.TabIndex = 21;
            this.lbl_Qty.Text = "Quantity";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Himalaya", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(213, 434);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(124, 35);
            this.btn_Refresh.TabIndex = 17;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Himalaya", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Save.Location = new System.Drawing.Point(515, 434);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(107, 35);
            this.btn_Save.TabIndex = 16;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // lbl_GST
            // 
            this.lbl_GST.AutoSize = true;
            this.lbl_GST.BackColor = System.Drawing.Color.Transparent;
            this.lbl_GST.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GST.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_GST.Location = new System.Drawing.Point(290, 383);
            this.lbl_GST.Name = "lbl_GST";
            this.lbl_GST.Size = new System.Drawing.Size(44, 32);
            this.lbl_GST.TabIndex = 22;
            this.lbl_GST.Text = "GST";
            // 
            // tb_GST
            // 
            this.tb_GST.Enabled = false;
            this.tb_GST.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_GST.Location = new System.Drawing.Point(340, 384);
            this.tb_GST.MaxLength = 4;
            this.tb_GST.Name = "tb_GST";
            this.tb_GST.Size = new System.Drawing.Size(63, 29);
            this.tb_GST.TabIndex = 13;
            this.tb_GST.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Discount.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discount.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Discount.Location = new System.Drawing.Point(448, 383);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(75, 32);
            this.lbl_Discount.TabIndex = 22;
            this.lbl_Discount.Text = "Discount";
            // 
            // tb_Discount
            // 
            this.tb_Discount.Enabled = false;
            this.tb_Discount.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Discount.Location = new System.Drawing.Point(526, 383);
            this.tb_Discount.MaxLength = 4;
            this.tb_Discount.Name = "tb_Discount";
            this.tb_Discount.Size = new System.Drawing.Size(64, 29);
            this.tb_Discount.TabIndex = 14;
            this.tb_Discount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_T1
            // 
            this.lbl_T1.AutoSize = true;
            this.lbl_T1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_T1.Font = new System.Drawing.Font("Microsoft Uighur", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_T1.ForeColor = System.Drawing.Color.DarkViolet;
            this.lbl_T1.Location = new System.Drawing.Point(409, 387);
            this.lbl_T1.Name = "lbl_T1";
            this.lbl_T1.Size = new System.Drawing.Size(20, 23);
            this.lbl_T1.TabIndex = 25;
            this.lbl_T1.Text = "%";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Uighur", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkViolet;
            this.label4.Location = new System.Drawing.Point(596, 387);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 23);
            this.label4.TabIndex = 26;
            this.label4.Text = "%";
            // 
            // lbl_Final_Bill
            // 
            this.lbl_Final_Bill.AutoSize = true;
            this.lbl_Final_Bill.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Final_Bill.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Final_Bill.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Final_Bill.Location = new System.Drawing.Point(622, 383);
            this.lbl_Final_Bill.Name = "lbl_Final_Bill";
            this.lbl_Final_Bill.Size = new System.Drawing.Size(73, 32);
            this.lbl_Final_Bill.TabIndex = 22;
            this.lbl_Final_Bill.Text = "Final Bill";
            // 
            // tb_Final_Bill
            // 
            this.tb_Final_Bill.Enabled = false;
            this.tb_Final_Bill.Font = new System.Drawing.Font("Mongolian Baiti", 14F);
            this.tb_Final_Bill.Location = new System.Drawing.Point(712, 384);
            this.tb_Final_Bill.MaxLength = 7;
            this.tb_Final_Bill.Name = "tb_Final_Bill";
            this.tb_Final_Bill.Size = new System.Drawing.Size(154, 29);
            this.tb_Final_Bill.TabIndex = 15;
            // 
            // frm_Add_New_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 481);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_T1);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Purchase);
            this.Controls.Add(this.tb_Discount);
            this.Controls.Add(this.tb_GST);
            this.Controls.Add(this.tb_Final_Bill);
            this.Controls.Add(this.tb_Cloth_Details);
            this.Controls.Add(this.gb_Customer_Details);
            this.Controls.Add(this.lbl_Discount);
            this.Controls.Add(this.lbl_GST);
            this.Controls.Add(this.lbl_Final_Bill);
            this.Controls.Add(this.lbl_Total_Bill);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Add New Customer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Add_New_Customer_Load);
            this.gb_Customer_Details.ResumeLayout(false);
            this.gb_Customer_Details.PerformLayout();
            this.gb_Purchase.ResumeLayout(false);
            this.gb_Purchase.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Customer_List)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gb_Customer_Details;
        private System.Windows.Forms.TextBox tb_Cloth_ID;
        private System.Windows.Forms.Label lbl_Customer_ID;
        private System.Windows.Forms.TextBox tb_Customer_Name;
        private System.Windows.Forms.Label lbl_Customer_Name;
        private System.Windows.Forms.TextBox tb_Cloth_Details;
        private System.Windows.Forms.TextBox tb_Sales_Price;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.Label lbl_Total_Bill;
        private System.Windows.Forms.Label lbl_Sales_Price;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.GroupBox gb_Purchase;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl_Qty;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_Cloth_Name;
        private System.Windows.Forms.TextBox tb_Mob_No;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.DateTimePicker dtp_Bill_Date;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_GST;
        private System.Windows.Forms.TextBox tb_GST;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.TextBox tb_Discount;
        private System.Windows.Forms.Label lbl_T1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Final_Bill;
        private System.Windows.Forms.TextBox tb_Final_Bill;
        private System.Windows.Forms.DataGridView dgv_Customer_List;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sr_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cloth_Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cloth_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sales_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
    }
}