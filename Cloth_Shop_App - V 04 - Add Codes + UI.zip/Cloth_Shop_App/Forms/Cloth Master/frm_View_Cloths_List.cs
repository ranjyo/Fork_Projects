﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Cloth_Master
{
    public partial class frm_View_Cloths_List : Form
    {
        public frm_View_Cloths_List()
        {
            InitializeComponent();
        }

        private void frm_View_Cloths_List_Load(object sender, EventArgs e)
        {
            Shared_Content.Bind_Grid(dgv_Cloths_List, "Select * From Cloth_Details");
        }

        private void cmb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_ComboBox("Cloth_Type", cmb_Cloth_Type, "Select Cloth_Type from Cloth_Type_Details where Cloth_Category = '" + cmb_Category.Text + "'");

            Shared_Content.Bind_Grid(dgv_Cloths_List, "Select * From Cloth_Details where Category = '" + cmb_Category.Text + "'");
        }

        private void cmb_Cloth_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_ComboBox("Cloth_Name", cmb_Cloth_Name, "Select Cloth_Name from Cloth_Details where Category = '" + cmb_Category.Text + "' And Cloth_Type = '" + cmb_Cloth_Type.Text + "'");

            Shared_Content.Bind_Grid(dgv_Cloths_List, "Select * From Cloth_Details where Category = '" + cmb_Category.Text + "' And Cloth_Type = '" + cmb_Cloth_Type.Text + "'");
        }

        private void cmb_Cloth_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            Shared_Content.Bind_Grid(dgv_Cloths_List, "Select * From Cloth_Details where Category = '" + cmb_Category.Text + "' And Cloth_Type = '" + cmb_Cloth_Type.Text + "' And Cloth_Name = '" + cmb_Cloth_Name.Text + "' ");
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            cmb_Category.SelectedIndex = -1;
            cmb_Cloth_Name.SelectedIndex = -1;
            cmb_Cloth_Type.SelectedIndex = -1;

            Shared_Content.Bind_Grid(dgv_Cloths_List, "Select * From Cloth_Details");
        }
    }
}
