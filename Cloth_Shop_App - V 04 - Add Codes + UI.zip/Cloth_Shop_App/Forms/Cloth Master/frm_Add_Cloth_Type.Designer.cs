﻿namespace Cloth_Shop_App.Forms
{
    partial class frm_Add_Cloth_Type
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Cloth_Type = new System.Windows.Forms.TextBox();
            this.tb_ClothType_ID = new System.Windows.Forms.TextBox();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.lbl_Cat_Type_ID = new System.Windows.Forms.Label();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.gb_ClothType_Details = new System.Windows.Forms.GroupBox();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_ClothType_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Cloth_Type
            // 
            this.tb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Cloth_Type.Location = new System.Drawing.Point(387, 241);
            this.tb_Cloth_Type.MaxLength = 40;
            this.tb_Cloth_Type.Name = "tb_Cloth_Type";
            this.tb_Cloth_Type.Size = new System.Drawing.Size(195, 32);
            this.tb_Cloth_Type.TabIndex = 2;
            this.tb_Cloth_Type.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_AlphaNumeric);
            // 
            // tb_ClothType_ID
            // 
            this.tb_ClothType_ID.Enabled = false;
            this.tb_ClothType_ID.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_ClothType_ID.Location = new System.Drawing.Point(387, 156);
            this.tb_ClothType_ID.MaxLength = 5;
            this.tb_ClothType_ID.Name = "tb_ClothType_ID";
            this.tb_ClothType_ID.Size = new System.Drawing.Size(195, 32);
            this.tb_ClothType_ID.TabIndex = 0;
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(139, 242);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(106, 37);
            this.lbl_Cloth_Type.TabIndex = 22;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // lbl_Cat_Type_ID
            // 
            this.lbl_Cat_Type_ID.AutoSize = true;
            this.lbl_Cat_Type_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cat_Type_ID.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cat_Type_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cat_Type_ID.Location = new System.Drawing.Point(139, 157);
            this.lbl_Cat_Type_ID.Name = "lbl_Cat_Type_ID";
            this.lbl_Cat_Type_ID.Size = new System.Drawing.Size(132, 37);
            this.lbl_Cat_Type_ID.TabIndex = 21;
            this.lbl_Cat_Type_ID.Text = "Cloth Type ID";
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(386, 74);
            this.cmb_Category.MaxLength = 20;
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(195, 31);
            this.cmb_Category.TabIndex = 1;
            // 
            // gb_ClothType_Details
            // 
            this.gb_ClothType_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_ClothType_Details.Controls.Add(this.tb_Cloth_Type);
            this.gb_ClothType_Details.Controls.Add(this.tb_ClothType_ID);
            this.gb_ClothType_Details.Controls.Add(this.lbl_Cloth_Type);
            this.gb_ClothType_Details.Controls.Add(this.lbl_Cat_Type_ID);
            this.gb_ClothType_Details.Controls.Add(this.cmb_Category);
            this.gb_ClothType_Details.Controls.Add(this.lbl_Category);
            this.gb_ClothType_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_ClothType_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_ClothType_Details.Location = new System.Drawing.Point(99, 34);
            this.gb_ClothType_Details.Name = "gb_ClothType_Details";
            this.gb_ClothType_Details.Size = new System.Drawing.Size(680, 337);
            this.gb_ClothType_Details.TabIndex = 12;
            this.gb_ClothType_Details.TabStop = false;
            this.gb_ClothType_Details.Text = "Cloth Type Details";
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category.Location = new System.Drawing.Point(139, 75);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(88, 37);
            this.lbl_Category.TabIndex = 20;
            this.lbl_Category.Text = "Category";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Uighur", 26F);
            this.btn_Save.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Save.Location = new System.Drawing.Point(374, 399);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(115, 47);
            this.btn_Save.TabIndex = 3;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // frm_Add_Cloth_Type
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 481);
            this.ControlBox = false;
            this.Controls.Add(this.gb_ClothType_Details);
            this.Controls.Add(this.btn_Save);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_Cloth_Type";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Cloth Type";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Add_Cloth_Type_Load);
            this.gb_ClothType_Details.ResumeLayout(false);
            this.gb_ClothType_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Cloth_Type;
        private System.Windows.Forms.TextBox tb_ClothType_ID;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.Label lbl_Cat_Type_ID;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.GroupBox gb_ClothType_Details;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.Button btn_Save;
    }
}