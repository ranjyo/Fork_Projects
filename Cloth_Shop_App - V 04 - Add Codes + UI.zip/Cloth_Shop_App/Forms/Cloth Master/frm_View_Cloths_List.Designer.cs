﻿namespace Cloth_Shop_App.Forms.Cloth_Master
{
    partial class frm_View_Cloths_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgv_Cloths_List = new System.Windows.Forms.DataGridView();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.cmb_Cloth_Type = new System.Windows.Forms.ComboBox();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.lbl_Cloth_Name = new System.Windows.Forms.Label();
            this.cmb_Cloth_Name = new System.Windows.Forms.ComboBox();
            this.btn_Refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cloths_List)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Cloths_List
            // 
            this.dgv_Cloths_List.AllowUserToAddRows = false;
            this.dgv_Cloths_List.AllowUserToDeleteRows = false;
            this.dgv_Cloths_List.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Californian FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Cloths_List.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Cloths_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Cloths_List.Location = new System.Drawing.Point(12, 84);
            this.dgv_Cloths_List.Name = "dgv_Cloths_List";
            this.dgv_Cloths_List.ReadOnly = true;
            this.dgv_Cloths_List.Size = new System.Drawing.Size(860, 336);
            this.dgv_Cloths_List.TabIndex = 4;
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(311, 23);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(106, 37);
            this.lbl_Cloth_Type.TabIndex = 28;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // cmb_Cloth_Type
            // 
            this.cmb_Cloth_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Type.FormattingEnabled = true;
            this.cmb_Cloth_Type.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Type.Location = new System.Drawing.Point(434, 24);
            this.cmb_Cloth_Type.Name = "cmb_Cloth_Type";
            this.cmb_Cloth_Type.Size = new System.Drawing.Size(135, 31);
            this.cmb_Cloth_Type.TabIndex = 2;
            this.cmb_Cloth_Type.SelectedIndexChanged += new System.EventHandler(this.cmb_Cloth_Type_SelectedIndexChanged);
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(135, 24);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(135, 31);
            this.cmb_Category.TabIndex = 1;
            this.cmb_Category.SelectedIndexChanged += new System.EventHandler(this.cmb_Category_SelectedIndexChanged);
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(21, 23);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(88, 37);
            this.lbl_Category_Name.TabIndex = 27;
            this.lbl_Category_Name.Text = "Category";
            // 
            // lbl_Cloth_Name
            // 
            this.lbl_Cloth_Name.AutoSize = true;
            this.lbl_Cloth_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Name.Location = new System.Drawing.Point(601, 23);
            this.lbl_Cloth_Name.Name = "lbl_Cloth_Name";
            this.lbl_Cloth_Name.Size = new System.Drawing.Size(114, 37);
            this.lbl_Cloth_Name.TabIndex = 30;
            this.lbl_Cloth_Name.Text = "Cloth Name";
            // 
            // cmb_Cloth_Name
            // 
            this.cmb_Cloth_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Name.FormattingEnabled = true;
            this.cmb_Cloth_Name.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Name.Location = new System.Drawing.Point(728, 24);
            this.cmb_Cloth_Name.Name = "cmb_Cloth_Name";
            this.cmb_Cloth_Name.Size = new System.Drawing.Size(135, 31);
            this.cmb_Cloth_Name.TabIndex = 3;
            this.cmb_Cloth_Name.SelectedIndexChanged += new System.EventHandler(this.cmb_Cloth_Name_SelectedIndexChanged);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(382, 429);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(116, 43);
            this.btn_Refresh.TabIndex = 31;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_View_Cloths_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 481);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.lbl_Cloth_Name);
            this.Controls.Add(this.cmb_Cloth_Name);
            this.Controls.Add(this.lbl_Cloth_Type);
            this.Controls.Add(this.cmb_Cloth_Type);
            this.Controls.Add(this.cmb_Category);
            this.Controls.Add(this.lbl_Category_Name);
            this.Controls.Add(this.dgv_Cloths_List);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_View_Cloths_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Cloths List";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_View_Cloths_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cloths_List)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgv_Cloths_List;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.Label lbl_Cloth_Name;
        private System.Windows.Forms.ComboBox cmb_Cloth_Name;
        private System.Windows.Forms.Button btn_Refresh;
    }
}