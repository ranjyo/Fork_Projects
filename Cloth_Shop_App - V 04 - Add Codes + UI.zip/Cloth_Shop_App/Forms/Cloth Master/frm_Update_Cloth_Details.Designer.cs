﻿namespace Cloth_Shop_App.Forms.Cloth
{
    partial class frm_Update_Cloth_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.gb_Update_Cloth = new System.Windows.Forms.GroupBox();
            this.tb_Cloth_Details = new System.Windows.Forms.TextBox();
            this.lbl_Cloth_Details = new System.Windows.Forms.Label();
            this.tb_Sales_Price = new System.Windows.Forms.TextBox();
            this.tb_Purchase_Price = new System.Windows.Forms.TextBox();
            this.lbl_Sales_Price = new System.Windows.Forms.Label();
            this.lbl_Puchase_Price = new System.Windows.Forms.Label();
            this.gb_Cloth_Type_Details = new System.Windows.Forms.GroupBox();
            this.tb_ClothType_ID = new System.Windows.Forms.TextBox();
            this.lbl_Cloth_Name = new System.Windows.Forms.Label();
            this.lbl_Cloth_Type = new System.Windows.Forms.Label();
            this.lbl_ClothType_ID = new System.Windows.Forms.Label();
            this.cmb_Cloth_Type = new System.Windows.Forms.ComboBox();
            this.cmb_Cloth_Name = new System.Windows.Forms.ComboBox();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.gb_Update_Cloth.SuspendLayout();
            this.gb_Cloth_Type_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Refresh.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Refresh.Location = new System.Drawing.Point(219, 423);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(150, 47);
            this.btn_Refresh.TabIndex = 21;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btn_Update.Font = new System.Drawing.Font("Microsoft Uighur", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.Crimson;
            this.btn_Update.Location = new System.Drawing.Point(569, 423);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(137, 47);
            this.btn_Update.TabIndex = 20;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            // 
            // gb_Update_Cloth
            // 
            this.gb_Update_Cloth.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Update_Cloth.Controls.Add(this.tb_Cloth_Details);
            this.gb_Update_Cloth.Controls.Add(this.lbl_Cloth_Details);
            this.gb_Update_Cloth.Controls.Add(this.tb_Sales_Price);
            this.gb_Update_Cloth.Controls.Add(this.tb_Purchase_Price);
            this.gb_Update_Cloth.Controls.Add(this.lbl_Sales_Price);
            this.gb_Update_Cloth.Controls.Add(this.lbl_Puchase_Price);
            this.gb_Update_Cloth.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Update_Cloth.ForeColor = System.Drawing.Color.Black;
            this.gb_Update_Cloth.Location = new System.Drawing.Point(13, 200);
            this.gb_Update_Cloth.Name = "gb_Update_Cloth";
            this.gb_Update_Cloth.Size = new System.Drawing.Size(859, 208);
            this.gb_Update_Cloth.TabIndex = 24;
            this.gb_Update_Cloth.TabStop = false;
            this.gb_Update_Cloth.Text = "Update Cloth Details";
            // 
            // tb_Cloth_Details
            // 
            this.tb_Cloth_Details.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Cloth_Details.Location = new System.Drawing.Point(376, 105);
            this.tb_Cloth_Details.MaxLength = 120;
            this.tb_Cloth_Details.Multiline = true;
            this.tb_Cloth_Details.Name = "tb_Cloth_Details";
            this.tb_Cloth_Details.Size = new System.Drawing.Size(294, 85);
            this.tb_Cloth_Details.TabIndex = 27;
            // 
            // lbl_Cloth_Details
            // 
            this.lbl_Cloth_Details.AutoSize = true;
            this.lbl_Cloth_Details.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Details.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Details.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Details.Location = new System.Drawing.Point(223, 124);
            this.lbl_Cloth_Details.Name = "lbl_Cloth_Details";
            this.lbl_Cloth_Details.Size = new System.Drawing.Size(121, 37);
            this.lbl_Cloth_Details.TabIndex = 28;
            this.lbl_Cloth_Details.Text = "Cloth Details";
            // 
            // tb_Sales_Price
            // 
            this.tb_Sales_Price.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Sales_Price.Location = new System.Drawing.Point(631, 29);
            this.tb_Sales_Price.MaxLength = 7;
            this.tb_Sales_Price.Name = "tb_Sales_Price";
            this.tb_Sales_Price.Size = new System.Drawing.Size(195, 32);
            this.tb_Sales_Price.TabIndex = 24;
            // 
            // tb_Purchase_Price
            // 
            this.tb_Purchase_Price.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_Purchase_Price.Location = new System.Drawing.Point(181, 29);
            this.tb_Purchase_Price.MaxLength = 7;
            this.tb_Purchase_Price.Name = "tb_Purchase_Price";
            this.tb_Purchase_Price.Size = new System.Drawing.Size(195, 32);
            this.tb_Purchase_Price.TabIndex = 23;
            // 
            // lbl_Sales_Price
            // 
            this.lbl_Sales_Price.AutoSize = true;
            this.lbl_Sales_Price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Sales_Price.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sales_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Sales_Price.Location = new System.Drawing.Point(452, 28);
            this.lbl_Sales_Price.Name = "lbl_Sales_Price";
            this.lbl_Sales_Price.Size = new System.Drawing.Size(98, 37);
            this.lbl_Sales_Price.TabIndex = 25;
            this.lbl_Sales_Price.Text = "Sales Price";
            // 
            // lbl_Puchase_Price
            // 
            this.lbl_Puchase_Price.AutoSize = true;
            this.lbl_Puchase_Price.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Puchase_Price.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Puchase_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Puchase_Price.Location = new System.Drawing.Point(27, 29);
            this.lbl_Puchase_Price.Name = "lbl_Puchase_Price";
            this.lbl_Puchase_Price.Size = new System.Drawing.Size(130, 37);
            this.lbl_Puchase_Price.TabIndex = 26;
            this.lbl_Puchase_Price.Text = "Purchase Price";
            // 
            // gb_Cloth_Type_Details
            // 
            this.gb_Cloth_Type_Details.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gb_Cloth_Type_Details.Controls.Add(this.tb_ClothType_ID);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Cloth_Type);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_ClothType_ID);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Cloth_Type);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Cloth_Name);
            this.gb_Cloth_Type_Details.Controls.Add(this.cmb_Category);
            this.gb_Cloth_Type_Details.Controls.Add(this.lbl_Category_Name);
            this.gb_Cloth_Type_Details.Font = new System.Drawing.Font("Lucida Bright", 7F);
            this.gb_Cloth_Type_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Cloth_Type_Details.Location = new System.Drawing.Point(12, 10);
            this.gb_Cloth_Type_Details.Name = "gb_Cloth_Type_Details";
            this.gb_Cloth_Type_Details.Size = new System.Drawing.Size(859, 179);
            this.gb_Cloth_Type_Details.TabIndex = 23;
            this.gb_Cloth_Type_Details.TabStop = false;
            this.gb_Cloth_Type_Details.Text = "Cloth Details";
            // 
            // tb_ClothType_ID
            // 
            this.tb_ClothType_ID.Enabled = false;
            this.tb_ClothType_ID.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.tb_ClothType_ID.Location = new System.Drawing.Point(630, 114);
            this.tb_ClothType_ID.MaxLength = 5;
            this.tb_ClothType_ID.Name = "tb_ClothType_ID";
            this.tb_ClothType_ID.Size = new System.Drawing.Size(195, 32);
            this.tb_ClothType_ID.TabIndex = 4;
            // 
            // lbl_Cloth_Name
            // 
            this.lbl_Cloth_Name.AutoSize = true;
            this.lbl_Cloth_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Name.Location = new System.Drawing.Point(26, 118);
            this.lbl_Cloth_Name.Name = "lbl_Cloth_Name";
            this.lbl_Cloth_Name.Size = new System.Drawing.Size(114, 37);
            this.lbl_Cloth_Name.TabIndex = 22;
            this.lbl_Cloth_Name.Text = "Cloth Name";
            // 
            // lbl_Cloth_Type
            // 
            this.lbl_Cloth_Type.AutoSize = true;
            this.lbl_Cloth_Type.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Cloth_Type.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cloth_Type.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Cloth_Type.Location = new System.Drawing.Point(451, 37);
            this.lbl_Cloth_Type.Name = "lbl_Cloth_Type";
            this.lbl_Cloth_Type.Size = new System.Drawing.Size(106, 37);
            this.lbl_Cloth_Type.TabIndex = 22;
            this.lbl_Cloth_Type.Text = "Cloth Type";
            // 
            // lbl_ClothType_ID
            // 
            this.lbl_ClothType_ID.AutoSize = true;
            this.lbl_ClothType_ID.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ClothType_ID.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ClothType_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_ClothType_ID.Location = new System.Drawing.Point(451, 113);
            this.lbl_ClothType_ID.Name = "lbl_ClothType_ID";
            this.lbl_ClothType_ID.Size = new System.Drawing.Size(132, 37);
            this.lbl_ClothType_ID.TabIndex = 21;
            this.lbl_ClothType_ID.Text = "Cloth Type ID";
            // 
            // cmb_Cloth_Type
            // 
            this.cmb_Cloth_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Type.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Type.FormattingEnabled = true;
            this.cmb_Cloth_Type.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Type.Location = new System.Drawing.Point(630, 38);
            this.cmb_Cloth_Type.Name = "cmb_Cloth_Type";
            this.cmb_Cloth_Type.Size = new System.Drawing.Size(195, 31);
            this.cmb_Cloth_Type.TabIndex = 2;
            // 
            // cmb_Cloth_Name
            // 
            this.cmb_Cloth_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Cloth_Name.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Cloth_Name.FormattingEnabled = true;
            this.cmb_Cloth_Name.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Cloth_Name.Location = new System.Drawing.Point(180, 119);
            this.cmb_Cloth_Name.Name = "cmb_Cloth_Name";
            this.cmb_Cloth_Name.Size = new System.Drawing.Size(195, 31);
            this.cmb_Cloth_Name.TabIndex = 3;
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.Font = new System.Drawing.Font("Mongolian Baiti", 16F);
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Gents",
            "Ladies",
            "Kids"});
            this.cmb_Category.Location = new System.Drawing.Point(180, 38);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(195, 31);
            this.cmb_Category.TabIndex = 1;
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Uighur", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(26, 37);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(88, 37);
            this.lbl_Category_Name.TabIndex = 20;
            this.lbl_Category_Name.Text = "Category";
            // 
            // frm_Update_Cloth_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 481);
            this.ControlBox = false;
            this.Controls.Add(this.gb_Update_Cloth);
            this.Controls.Add(this.gb_Cloth_Type_Details);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Update);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Update_Cloth_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Cloth Details";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Update_Cloth_Details_Load);
            this.gb_Update_Cloth.ResumeLayout(false);
            this.gb_Update_Cloth.PerformLayout();
            this.gb_Cloth_Type_Details.ResumeLayout(false);
            this.gb_Cloth_Type_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.GroupBox gb_Update_Cloth;
        private System.Windows.Forms.GroupBox gb_Cloth_Type_Details;
        private System.Windows.Forms.TextBox tb_ClothType_ID;
        private System.Windows.Forms.Label lbl_Cloth_Name;
        private System.Windows.Forms.Label lbl_Cloth_Type;
        private System.Windows.Forms.Label lbl_ClothType_ID;
        private System.Windows.Forms.ComboBox cmb_Cloth_Type;
        private System.Windows.Forms.ComboBox cmb_Cloth_Name;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.TextBox tb_Sales_Price;
        private System.Windows.Forms.TextBox tb_Purchase_Price;
        private System.Windows.Forms.Label lbl_Sales_Price;
        private System.Windows.Forms.Label lbl_Puchase_Price;
        private System.Windows.Forms.TextBox tb_Cloth_Details;
        private System.Windows.Forms.Label lbl_Cloth_Details;
    }
}