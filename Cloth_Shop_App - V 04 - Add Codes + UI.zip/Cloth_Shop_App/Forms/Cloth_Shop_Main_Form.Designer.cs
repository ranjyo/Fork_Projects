﻿namespace Cloth_Shop_App.Forms
{
    partial class Cloth_Shop_Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cloth_Shop_Main_Form));
            this.pnl_Main_Menu = new System.Windows.Forms.Panel();
            this.lbl_Devloper_Contact = new System.Windows.Forms.Label();
            this.btn_Reports = new System.Windows.Forms.Button();
            this.btn_Expences = new System.Windows.Forms.Button();
            this.btn_Dealer = new System.Windows.Forms.Button();
            this.btn_Cloths = new System.Windows.Forms.Button();
            this.btn_User_Mgt = new System.Windows.Forms.Button();
            this.btn_Staff = new System.Windows.Forms.Button();
            this.btn_Stock = new System.Windows.Forms.Button();
            this.btn_Customer = new System.Windows.Forms.Button();
            this.pb_App_Logo = new System.Windows.Forms.PictureBox();
            pnl_Container = new System.Windows.Forms.Panel();
            this.pnl_Head = new System.Windows.Forms.Panel();
            this.pnl_Main_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_App_Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_Main_Menu
            // 
            this.pnl_Main_Menu.BackColor = System.Drawing.Color.DarkKhaki;
            this.pnl_Main_Menu.Controls.Add(this.lbl_Devloper_Contact);
            this.pnl_Main_Menu.Controls.Add(this.btn_Reports);
            this.pnl_Main_Menu.Controls.Add(this.btn_Expences);
            this.pnl_Main_Menu.Controls.Add(this.btn_Dealer);
            this.pnl_Main_Menu.Controls.Add(this.btn_Cloths);
            this.pnl_Main_Menu.Controls.Add(this.btn_User_Mgt);
            this.pnl_Main_Menu.Controls.Add(this.btn_Staff);
            this.pnl_Main_Menu.Controls.Add(this.btn_Stock);
            this.pnl_Main_Menu.Controls.Add(this.btn_Customer);
            this.pnl_Main_Menu.Controls.Add(this.pb_App_Logo);
            this.pnl_Main_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_Main_Menu.Location = new System.Drawing.Point(0, 0);
            this.pnl_Main_Menu.Name = "pnl_Main_Menu";
            this.pnl_Main_Menu.Size = new System.Drawing.Size(250, 599);
            this.pnl_Main_Menu.TabIndex = 0;
            // 
            // lbl_Devloper_Contact
            // 
            this.lbl_Devloper_Contact.AutoSize = true;
            this.lbl_Devloper_Contact.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Devloper_Contact.Font = new System.Drawing.Font("Microsoft Uighur", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Devloper_Contact.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_Devloper_Contact.Location = new System.Drawing.Point(13, 561);
            this.lbl_Devloper_Contact.Name = "lbl_Devloper_Contact";
            this.lbl_Devloper_Contact.Size = new System.Drawing.Size(211, 29);
            this.lbl_Devloper_Contact.TabIndex = 23;
            this.lbl_Devloper_Contact.Text = "Karad Softwares - 9876543210";
            // 
            // btn_Reports
            // 
            this.btn_Reports.BackColor = System.Drawing.Color.White;
            this.btn_Reports.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reports.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Reports.Location = new System.Drawing.Point(12, 494);
            this.btn_Reports.Name = "btn_Reports";
            this.btn_Reports.Size = new System.Drawing.Size(212, 48);
            this.btn_Reports.TabIndex = 8;
            this.btn_Reports.Text = "Reports";
            this.btn_Reports.UseVisualStyleBackColor = false;
            // 
            // btn_Expences
            // 
            this.btn_Expences.BackColor = System.Drawing.Color.White;
            this.btn_Expences.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Expences.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Expences.Location = new System.Drawing.Point(12, 386);
            this.btn_Expences.Name = "btn_Expences";
            this.btn_Expences.Size = new System.Drawing.Size(212, 48);
            this.btn_Expences.TabIndex = 6;
            this.btn_Expences.Text = "Expence";
            this.btn_Expences.UseVisualStyleBackColor = false;
            // 
            // btn_Dealer
            // 
            this.btn_Dealer.BackColor = System.Drawing.Color.White;
            this.btn_Dealer.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dealer.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Dealer.Location = new System.Drawing.Point(12, 278);
            this.btn_Dealer.Name = "btn_Dealer";
            this.btn_Dealer.Size = new System.Drawing.Size(212, 48);
            this.btn_Dealer.TabIndex = 4;
            this.btn_Dealer.Text = "Dealer";
            this.btn_Dealer.UseVisualStyleBackColor = false;
            // 
            // btn_Cloths
            // 
            this.btn_Cloths.BackColor = System.Drawing.Color.White;
            this.btn_Cloths.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cloths.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Cloths.Location = new System.Drawing.Point(12, 170);
            this.btn_Cloths.Name = "btn_Cloths";
            this.btn_Cloths.Size = new System.Drawing.Size(212, 48);
            this.btn_Cloths.TabIndex = 2;
            this.btn_Cloths.Text = "Cloths";
            this.btn_Cloths.UseVisualStyleBackColor = false;
            this.btn_Cloths.Click += new System.EventHandler(this.btn_Cloths_Click);
            // 
            // btn_User_Mgt
            // 
            this.btn_User_Mgt.BackColor = System.Drawing.Color.White;
            this.btn_User_Mgt.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_User_Mgt.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_User_Mgt.Location = new System.Drawing.Point(12, 440);
            this.btn_User_Mgt.Name = "btn_User_Mgt";
            this.btn_User_Mgt.Size = new System.Drawing.Size(212, 48);
            this.btn_User_Mgt.TabIndex = 7;
            this.btn_User_Mgt.Text = "User Management";
            this.btn_User_Mgt.UseVisualStyleBackColor = false;
            // 
            // btn_Staff
            // 
            this.btn_Staff.BackColor = System.Drawing.Color.White;
            this.btn_Staff.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Staff.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Staff.Location = new System.Drawing.Point(12, 332);
            this.btn_Staff.Name = "btn_Staff";
            this.btn_Staff.Size = new System.Drawing.Size(212, 48);
            this.btn_Staff.TabIndex = 5;
            this.btn_Staff.Text = "Staff";
            this.btn_Staff.UseVisualStyleBackColor = false;
            // 
            // btn_Stock
            // 
            this.btn_Stock.BackColor = System.Drawing.Color.White;
            this.btn_Stock.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Stock.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Stock.Location = new System.Drawing.Point(12, 224);
            this.btn_Stock.Name = "btn_Stock";
            this.btn_Stock.Size = new System.Drawing.Size(212, 48);
            this.btn_Stock.TabIndex = 3;
            this.btn_Stock.Text = "Stock";
            this.btn_Stock.UseVisualStyleBackColor = false;
            // 
            // btn_Customer
            // 
            this.btn_Customer.BackColor = System.Drawing.Color.White;
            this.btn_Customer.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customer.ForeColor = System.Drawing.Color.OrangeRed;
            this.btn_Customer.Location = new System.Drawing.Point(12, 116);
            this.btn_Customer.Name = "btn_Customer";
            this.btn_Customer.Size = new System.Drawing.Size(212, 48);
            this.btn_Customer.TabIndex = 1;
            this.btn_Customer.Text = "Customer";
            this.btn_Customer.UseVisualStyleBackColor = false;
            this.btn_Customer.Click += new System.EventHandler(this.btn_Customer_Click);
            // 
            // pb_App_Logo
            // 
            this.pb_App_Logo.BackColor = System.Drawing.Color.DarkTurquoise;
            this.pb_App_Logo.Image = global::Cloth_Shop_App.Properties.Resources.Cloth_Shop_LOGO;
            this.pb_App_Logo.Location = new System.Drawing.Point(0, 1);
            this.pb_App_Logo.Name = "pb_App_Logo";
            this.pb_App_Logo.Size = new System.Drawing.Size(247, 101);
            this.pb_App_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_App_Logo.TabIndex = 0;
            this.pb_App_Logo.TabStop = false;
            // 
            // pnl_Container
            // 
            pnl_Container.BackColor = System.Drawing.Color.RosyBrown;
            pnl_Container.Location = new System.Drawing.Point(245, 102);
            pnl_Container.Name = "pnl_Container";
            pnl_Container.Size = new System.Drawing.Size(890, 500);
            pnl_Container.TabIndex = 1;
            // 
            // pnl_Head
            // 
            this.pnl_Head.BackColor = System.Drawing.Color.DarkKhaki;
            this.pnl_Head.Location = new System.Drawing.Point(245, 0);
            this.pnl_Head.Name = "pnl_Head";
            this.pnl_Head.Size = new System.Drawing.Size(890, 102);
            this.pnl_Head.TabIndex = 2;
            // 
            // Cloth_Shop_Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 599);
            this.Controls.Add(this.pnl_Head);
            this.Controls.Add(pnl_Container);
            this.Controls.Add(this.pnl_Main_Menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Cloth_Shop_Main_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mr. Perfect Cloth Shop";
            this.Load += new System.EventHandler(this.Cloth_Shop_Main_Form_Load);
            this.pnl_Main_Menu.ResumeLayout(false);
            this.pnl_Main_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_App_Logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Main_Menu;
        private System.Windows.Forms.PictureBox pb_App_Logo;
        private System.Windows.Forms.Button btn_Reports;
        private System.Windows.Forms.Button btn_Expences;
        private System.Windows.Forms.Button btn_Dealer;
        private System.Windows.Forms.Button btn_Cloths;
        private System.Windows.Forms.Button btn_User_Mgt;
        private System.Windows.Forms.Button btn_Staff;
        private System.Windows.Forms.Button btn_Stock;
        private System.Windows.Forms.Button btn_Customer;
        private System.Windows.Forms.Label lbl_Devloper_Contact;
        private System.Windows.Forms.Panel pnl_Head;
        public static System.Windows.Forms.Panel pnl_Container;
    }
}