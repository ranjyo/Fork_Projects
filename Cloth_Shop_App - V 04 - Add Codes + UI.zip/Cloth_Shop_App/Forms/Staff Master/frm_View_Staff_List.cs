﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Staff_Master
{
    public partial class frm_View_Staff_List : Form
    {
        public frm_View_Staff_List()
        {
            InitializeComponent();
        }

        private void frm_View_Staff_List_Load(object sender, EventArgs e)
        {
            Shared_Content.Bind_Grid(dgv_Staff_List, "Select Staff_ID, Staff_Name, Mobile_No, Adhaar_No, PAN_No, Designation, Bank_Details From Staff_Details");
        }
    }
}
