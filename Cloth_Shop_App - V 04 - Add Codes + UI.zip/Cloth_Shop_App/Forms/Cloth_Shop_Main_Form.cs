﻿using Cloth_Shop_App.Forms.Cloth;
using Cloth_Shop_App.Forms.Customer_Master;
using Cloth_Shop_App.Headers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms
{
    public partial class Cloth_Shop_Main_Form : Form
    {
        public Cloth_Shop_Main_Form()
        {
            InitializeComponent();
        }

        private void btn_Customer_Click(object sender, EventArgs e)
        {
            frm_Add_New_Customer Obj = new frm_Add_New_Customer() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            pnl_Container.Controls.Clear();
            pnl_Container.Controls.Add(Obj);
            Obj.Show();

            UC_Customer UC = new UC_Customer();

            pnl_Head.Controls.Clear();
            this.pnl_Head.Controls.Add(UC);
            UC.Show();
        }

        private void btn_Cloths_Click(object sender, EventArgs e)
        {
            frm_Add_Cloth Obj = new frm_Add_Cloth() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            pnl_Container.Controls.Clear();
            pnl_Container.Controls.Add(Obj);
            Obj.Show();

            UC_Cloths UC = new UC_Cloths();

            pnl_Head.Controls.Clear();
            this.pnl_Head.Controls.Add(UC);
            UC.Show();
        }

        private void Cloth_Shop_Main_Form_Load(object sender, EventArgs e)
        {

        }
    }
}
