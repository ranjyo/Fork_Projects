﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Dealer_Master
{
    public partial class frm_Add_New_Dealer : Form
    {
        public frm_Add_New_Dealer()
        {
            InitializeComponent();
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }
        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == (char)Keys.Space) || (e.KeyChar == (char)Keys.ShiftKey) || (e.KeyChar == (char)Keys.CapsLock)))
            {
                e.Handled = true;
            }
        }
        private void Only_AlphaNumeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetterOrDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back) || (e.KeyChar == (char)Keys.Space) || (e.KeyChar == (char)Keys.ShiftKey) || (e.KeyChar == (char)Keys.CapsLock)))
            {
                e.Handled = true;
            }
        }
        void Clear_Controls()
        {
            tb_Dealer_ID.Text = Convert.ToString(Shared_Content.Auto_Incr("Dealer_Details", "Dealer_ID", 101));

            tb_Dealer_Name.Clear();
            tb_Mob_No.Clear();
            tb_Alt_Contact_No.Clear();
            tb_Office_Address.Clear();
            tb_Udyam_Adhaar_No.Clear();
            tb_PAN_No.Clear();
            tb_Bank_Details.Clear();
           
            dtp_Tie_Up_Date.ResetText();
        }
        private void frm_Add_New_Dealer_Load(object sender, EventArgs e)
        {
            Clear_Controls();
            tb_Dealer_Name.Focus();
        }
        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            tb_Dealer_Name.Focus();
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            Shared_Content.Con_Open();

            if (tb_Dealer_Name.Text != "" && tb_Mob_No.Text != "" && tb_Alt_Contact_No.Text != "" && tb_Office_Address.Text != "" && tb_Udyam_Adhaar_No.Text != "" && tb_PAN_No.Text != "" && tb_Bank_Details.Text != "")
            {
                SqlCommand cmd = new SqlCommand("Insert Into Dealer_Details Values (@ID, @Name, @Mob_No, @Alt_No, @Off_Address, @Date, @Adhar_No, @PAN_No, @BankDetails) ", Shared_Content.Con);

                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = tb_Dealer_ID.Text;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = tb_Dealer_Name.Text;
                cmd.Parameters.Add("@Mob_No", SqlDbType.Decimal).Value = tb_Mob_No.Text;
                cmd.Parameters.Add("@Alt_No", SqlDbType.Decimal).Value = tb_Alt_Contact_No.Text;
                cmd.Parameters.Add("@Off_Address", SqlDbType.NVarChar).Value = tb_Office_Address.Text;
                cmd.Parameters.Add("@Date", SqlDbType.Date).Value = dtp_Tie_Up_Date.Value.Date;
                cmd.Parameters.Add("@Adhar_No", SqlDbType.Decimal).Value = tb_Udyam_Adhaar_No.Text;
                cmd.Parameters.Add("@PAN_No", SqlDbType.NVarChar).Value = tb_PAN_No.Text;
                cmd.Parameters.Add("@BankDetails", SqlDbType.NVarChar).Value = tb_Bank_Details.Text;
                
                cmd.ExecuteNonQuery();

                MessageBox.Show("Dealer Details Saved Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("1st Fill All The Fields!!!", "Fill Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            Shared_Content.Con_Close();

        }
    }
}
