﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Forms.Dealer_Master
{
    public partial class frm_View_Dealer_List : Form
    {
        public frm_View_Dealer_List()
        {
            InitializeComponent();
        }

        private void frm_View_Dealer_List_Load(object sender, EventArgs e)
        {
            Shared_Content.Bind_Grid(dgv_Dealer_List, "Select Dealer_ID, Dealer_Name, Mobile_No,Office_Address, Udyam_Adhaar_No, Bank_Details From Dealer_Details");
        }
    }
}
