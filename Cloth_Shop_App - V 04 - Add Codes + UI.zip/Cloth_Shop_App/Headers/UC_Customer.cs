﻿using Cloth_Shop_App.Forms;
using Cloth_Shop_App.Forms.Customer_Master;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Headers
{
    public partial class UC_Customer : UserControl
    {
        public UC_Customer()
        {
            InitializeComponent();
        }

        private void btn_Add_Customer_Click(object sender, EventArgs e)
        {
            frm_Add_New_Customer Obj = new frm_Add_New_Customer() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }

        private void btn_View_Cutomer_List_Click(object sender, EventArgs e)
        {
            frm_Customer_List Obj = new frm_Customer_List() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }
    }
}
