﻿namespace Cloth_Shop_App.Headers
{
    partial class UC_Customer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_View_Cutomer_List = new System.Windows.Forms.Button();
            this.btn_Add_Customer = new System.Windows.Forms.Button();
            this.lbl_Customer_Header = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_View_Cutomer_List
            // 
            this.btn_View_Cutomer_List.BackColor = System.Drawing.Color.White;
            this.btn_View_Cutomer_List.Font = new System.Drawing.Font("Perpetua", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Cutomer_List.ForeColor = System.Drawing.Color.DeepPink;
            this.btn_View_Cutomer_List.Location = new System.Drawing.Point(533, 62);
            this.btn_View_Cutomer_List.Name = "btn_View_Cutomer_List";
            this.btn_View_Cutomer_List.Size = new System.Drawing.Size(281, 34);
            this.btn_View_Cutomer_List.TabIndex = 16;
            this.btn_View_Cutomer_List.Text = "View Customer List";
            this.btn_View_Cutomer_List.UseVisualStyleBackColor = false;
            this.btn_View_Cutomer_List.Click += new System.EventHandler(this.btn_View_Cutomer_List_Click);
            // 
            // btn_Add_Customer
            // 
            this.btn_Add_Customer.BackColor = System.Drawing.Color.White;
            this.btn_Add_Customer.Font = new System.Drawing.Font("Perpetua", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_Customer.ForeColor = System.Drawing.Color.DeepPink;
            this.btn_Add_Customer.Location = new System.Drawing.Point(76, 62);
            this.btn_Add_Customer.Name = "btn_Add_Customer";
            this.btn_Add_Customer.Size = new System.Drawing.Size(281, 34);
            this.btn_Add_Customer.TabIndex = 15;
            this.btn_Add_Customer.Text = "Add New Customer";
            this.btn_Add_Customer.UseVisualStyleBackColor = false;
            this.btn_Add_Customer.Click += new System.EventHandler(this.btn_Add_Customer_Click);
            // 
            // lbl_Customer_Header
            // 
            this.lbl_Customer_Header.AutoSize = true;
            this.lbl_Customer_Header.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Customer_Header.Font = new System.Drawing.Font("Lucida Bright", 30F, System.Drawing.FontStyle.Bold);
            this.lbl_Customer_Header.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl_Customer_Header.Location = new System.Drawing.Point(274, 6);
            this.lbl_Customer_Header.Name = "lbl_Customer_Header";
            this.lbl_Customer_Header.Size = new System.Drawing.Size(361, 45);
            this.lbl_Customer_Header.TabIndex = 14;
            this.lbl_Customer_Header.Text = "Customer Master";
            // 
            // UC_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkKhaki;
            this.Controls.Add(this.btn_View_Cutomer_List);
            this.Controls.Add(this.btn_Add_Customer);
            this.Controls.Add(this.lbl_Customer_Header);
            this.Name = "UC_Customer";
            this.Size = new System.Drawing.Size(890, 102);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_View_Cutomer_List;
        private System.Windows.Forms.Button btn_Add_Customer;
        private System.Windows.Forms.Label lbl_Customer_Header;
    }
}
