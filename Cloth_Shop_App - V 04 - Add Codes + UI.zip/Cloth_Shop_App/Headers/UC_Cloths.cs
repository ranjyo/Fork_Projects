﻿using Cloth_Shop_App.Forms;
using Cloth_Shop_App.Forms.Cloth;
using Cloth_Shop_App.Forms.Cloth_Master;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cloth_Shop_App.Headers
{
    public partial class UC_Cloths : UserControl
    {
        public UC_Cloths()
        {
            InitializeComponent();
        }

        private void btn_Add_Cloth_Type_Click(object sender, EventArgs e)
        {
            frm_Add_Cloth_Type Obj = new frm_Add_Cloth_Type() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }

        private void btn_Add_Cloth_Click(object sender, EventArgs e)
        {
            frm_Add_Cloth Obj = new frm_Add_Cloth() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }

        private void btn_Update_Cloth_Click(object sender, EventArgs e)
        {
            frm_Update_Cloth_Details Obj = new frm_Update_Cloth_Details() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }

        private void btn_Cloth_List_Click(object sender, EventArgs e)
        {
            frm_View_Cloths_List Obj = new frm_View_Cloths_List() { TopLevel = false, TopMost = true };
            Obj.FormBorderStyle = FormBorderStyle.None;

            Cloth_Shop_Main_Form.pnl_Container.Controls.Clear();
            Cloth_Shop_Main_Form.pnl_Container.Controls.Add(Obj);
            Obj.Show();
        }
    }
}
